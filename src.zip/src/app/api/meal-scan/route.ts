import { NextRequest, NextResponse } from "next/server";

type OpenAIResponse = {
  output_text?: string;
  output?: Array<{
    type?: string;
    content?: Array<{ type?: string; text?: string }>;
  }>;
  error?: { message?: string };
};

function extractText(data: OpenAIResponse) {
  if (typeof data.output_text === "string" && data.output_text.trim()) return data.output_text;
  for (const item of data.output ?? []) {
    for (const content of item.content ?? []) {
      if (typeof content.text === "string" && content.text.trim()) return content.text;
    }
  }
  return "";
}

function parseJson(text: string) {
  const trimmed = text.trim();
  try {
    return JSON.parse(trimmed);
  } catch {
    const start = trimmed.indexOf("{");
    const end = trimmed.lastIndexOf("}");
    if (start >= 0 && end > start) return JSON.parse(trimmed.slice(start, end + 1));
    throw new Error("The model did not return valid JSON.");
  }
}

export async function POST(request: NextRequest) {
  try {
    const key = process.env.OPENAI_API_KEY;
    if (!key) {
      return NextResponse.json(
        { error: "AI Meal Scan is installed, but OPENAI_API_KEY is not configured on the server yet." },
        { status: 503 }
      );
    }

    const body = (await request.json()) as { imageData?: string };
    const imageData = body.imageData?.trim();
    if (!imageData || !imageData.startsWith("data:image/")) {
      return NextResponse.json({ error: "A valid image is required." }, { status: 400 });
    }
    if (imageData.length > 12_000_000) {
      return NextResponse.json({ error: "Image is too large." }, { status: 413 });
    }

    const model = process.env.MUCIPES_AI_MODEL || "gpt-5.6-luna";
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        input: [
          {
            role: "user",
            content: [
              {
                type: "input_text",
                text:
                  "You are the meal-estimation module inside a nutrition tracker. Inspect this food photo. Estimate the visible edible foods and portions. Return ONLY JSON with this shape: {\"items\":[{\"name\":string,\"grams\":number,\"caloriesPer100\":number,\"proteinPer100\":number,\"carbsPer100\":number,\"fatPer100\":number,\"confidence\":number}],\"note\":string}. Use realistic nutrition per 100 g and realistic visible portion grams. Do not claim precision. If an ingredient cannot be identified, use a descriptive generic name. confidence is 0 to 1. Do not include cutlery, plates, drinks unless visibly consumed as part of the meal.",
              },
              { type: "input_image", image_url: imageData, detail: "high" },
            ],
          },
        ],
      }),
    });

    const data = (await response.json()) as OpenAIResponse;
    if (!response.ok) {
      return NextResponse.json(
        { error: data.error?.message || "AI meal scan request failed." },
        { status: response.status }
      );
    }

    const text = extractText(data);
    if (!text) return NextResponse.json({ error: "AI meal scan returned no result." }, { status: 502 });
    const parsed = parseJson(text) as { items?: unknown[]; note?: string };
    return NextResponse.json({
      items: Array.isArray(parsed.items) ? parsed.items.slice(0, 12) : [],
      note: typeof parsed.note === "string" ? parsed.note : "Review estimated portions before logging.",
    });
  } catch (error) {
    console.error("Mucipes meal scan error:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Meal scan failed." },
      { status: 500 }
    );
  }
}
