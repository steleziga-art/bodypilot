import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Mucipes",
    short_name: "Mucipes",
    description: "Simple training, nutrition and progress tracking.",
    start_url: "/",
    display: "standalone",
    background_color: "#f8fafc",
    theme_color: "#10b981",
    orientation: "portrait-primary",
    categories: ["fitness", "health", "lifestyle"],
    icons: [],
  };
}
