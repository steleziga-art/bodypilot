"use client";

import { useMemo, useState } from "react";
import { formatEnergy, formatWeight, type MucipesDisplaySettings } from "@/lib/mucipes/display";

type Goals = { calories: number; protein: number; carbs: number; fat: number };
type BodyProfile = { goal: "lose" | "maintain" | "gain"; targetWeight: number; trainingDays: number; weeklyRate: number };
type NutritionDay = { date: string; calories: number; protein: number; carbs: number; fat: number };
type WeightEntry = { id: number; date: string; weight: number };
type Workout = { id: string; name: string; finishedAt: string; durationSeconds: number; exercises: Array<{ exerciseName: string; sets: Array<{ weight: number; reps: number; completed?: boolean }> }> };

function round1(value: number) { return Math.round(value * 10) / 10; }

function buildInsights({ goals, profile, nutritionHistory, weightEntries, trainingHistory, display }: { goals: Goals; profile: BodyProfile; nutritionHistory: NutritionDay[]; weightEntries: WeightEntry[]; trainingHistory: Workout[]; display: MucipesDisplaySettings }) {
  const now = Date.now();
  const weekAgo = now - 7 * 86400000;
  const monthAgo = now - 30 * 86400000;
  const weeklyWorkouts = trainingHistory.filter((w) => new Date(w.finishedAt).getTime() >= weekAgo).length;
  const recentNutrition = nutritionHistory.filter((d) => new Date(d.date).getTime() >= weekAgo);
  const avgCalories = recentNutrition.length ? Math.round(recentNutrition.reduce((sum, d) => sum + d.calories, 0) / recentNutrition.length) : null;
  const avgProtein = recentNutrition.length ? Math.round(recentNutrition.reduce((sum, d) => sum + d.protein, 0) / recentNutrition.length) : null;
  const sortedWeights = [...weightEntries].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const latest = sortedWeights.at(-1)?.weight ?? null;
  const monthWeights = sortedWeights.filter((entry) => new Date(entry.date).getTime() >= monthAgo);
  const monthStart = monthWeights[0]?.weight ?? null;
  const change = latest !== null && monthStart !== null ? round1(latest - monthStart) : null;

  const insights: Array<{ title: string; detail: string; action: string }> = [];
  if (weeklyWorkouts < profile.trainingDays) {
    insights.push({ title: "Training frequency", detail: `${weeklyWorkouts} of ${profile.trainingDays} planned sessions are logged in the last 7 days.`, action: "Keep the next session simple and complete the planned week before adding extra volume." });
  } else {
    insights.push({ title: "Training frequency", detail: `${weeklyWorkouts} workouts are logged in the last 7 days.`, action: "Your frequency is on target. Progress load or reps only where recovery and form are good." });
  }
  if (avgProtein !== null && avgProtein < goals.protein * 0.9) {
    insights.push({ title: "Protein consistency", detail: `Your recent average is ${avgProtein} g versus a ${goals.protein} g target.`, action: `Aim for roughly ${Math.max(0, goals.protein - avgProtein)} g more protein across the day.` });
  } else if (avgProtein !== null) {
    insights.push({ title: "Protein consistency", detail: `Your recent average is ${avgProtein} g and is close to your ${goals.protein} g target.`, action: "Keep protein distributed across meals; no major change is needed from this signal alone." });
  }
  if (avgCalories !== null) {
    const delta = avgCalories - goals.calories;
    insights.push({ title: "Energy intake", detail: `7-day average: ${formatEnergy(avgCalories, display.energyUnit)} (${delta >= 0 ? "+" : ""}${formatEnergy(delta, display.energyUnit)} vs target).`, action: Math.abs(delta) <= goals.calories * 0.08 ? "Your recent intake is close to target." : "Use the weekly weight trend before changing your target; a single day is not enough." });
  }
  if (change !== null) {
    insights.push({ title: "Weight trend", detail: `Recent recorded change: ${change > 0 ? "+" : ""}${formatWeight(change, display.units)}.`, action: profile.goal === "lose" ? "For fat loss, judge the trend over multiple weigh-ins rather than reacting to one measurement." : profile.goal === "gain" ? "For muscle gain, use a slow trend and pair it with strength performance." : "For maintenance, small short-term fluctuations are expected." });
  }
  if (!insights.length) insights.push({ title: "Build your baseline", detail: "Log a few workouts, nutrition days and weigh-ins so Mucipes can compare trends.", action: "Consistency of data matters more than adding more metrics." });
  return insights.slice(0, 4);
}

export default function CoachPage({ goals, profile, nutritionHistory, weightEntries, trainingHistory, displaySettings, onOpenPlan }: { goals: Goals; profile: BodyProfile; nutritionHistory: NutritionDay[]; weightEntries: WeightEntry[]; trainingHistory: Workout[]; displaySettings: MucipesDisplaySettings; onOpenPlan: () => void }) {
  const insights = useMemo(() => buildInsights({ goals, profile, nutritionHistory, weightEntries, trainingHistory, display: displaySettings }), [goals, profile, nutritionHistory, weightEntries, trainingHistory, displaySettings]);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);

  async function askCoach() {
    if (!question.trim()) return;
    setLoading(true);
    setAnswer("");
    const context = {
      goals,
      profile,
      nutrition: nutritionHistory.slice(-30),
      weights: weightEntries.slice(-30),
      training: trainingHistory.slice(0, 20).map((w) => ({ name: w.name, finishedAt: w.finishedAt, durationSeconds: w.durationSeconds, exercises: w.exercises.map((e) => ({ name: e.exerciseName, sets: e.sets.map((s) => ({ weight: s.weight, reps: s.reps })) })) })),
    };
    try {
      const response = await fetch("/api/coach", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question: question.trim(), context }) });
      const data = await response.json();
      if (response.ok && typeof data.answer === "string") setAnswer(data.answer);
      else setAnswer(localFallback(question, insights));
    } catch {
      setAnswer(localFallback(question, insights));
    } finally {
      setLoading(false);
    }
  }

  return <div className="space-y-5">
    <header className="flex flex-wrap items-end justify-between gap-4"><div><p className="text-xs font-black uppercase tracking-[0.18em] text-emerald-600">Mucipes Coach</p><h1 className="mt-1 text-4xl font-black tracking-tight">Your data, interpreted.</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">Coach combines training, nutrition and progress. It does not silently change your plan; you decide whether to apply suggestions.</p></div><button onClick={onOpenPlan} className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-black">Open guided plan</button></header>

    <section className="grid gap-3 md:grid-cols-2">{insights.map((insight) => <article key={insight.title} className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm"><p className="text-xs font-black uppercase tracking-widest text-emerald-600">{insight.title}</p><p className="mt-3 text-lg font-black text-slate-950">{insight.detail}</p><p className="mt-2 text-sm leading-6 text-slate-500">{insight.action}</p></article>)}</section>

    <section className="rounded-[2rem] bg-slate-950 p-5 text-white shadow-sm sm:p-6"><p className="text-xs font-black uppercase tracking-widest text-emerald-400">Ask about your data</p><h2 className="mt-2 text-2xl font-black">What do you want to understand?</h2><p className="mt-2 text-sm text-slate-300">Examples: “Why has my chest press stalled?”, “Am I eating close to target?”, “How was my last month?”</p><div className="mt-4 flex flex-col gap-2 sm:flex-row"><input value={question} onChange={(event) => setQuestion(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") void askCoach(); }} placeholder="Ask Mucipes Coach…" className="min-w-0 flex-1 rounded-2xl border border-slate-700 bg-slate-900 px-4 py-3 text-base text-white outline-none focus:border-emerald-400"/><button onClick={() => void askCoach()} disabled={loading || !question.trim()} className="rounded-2xl bg-emerald-400 px-5 py-3 font-black text-slate-950 disabled:opacity-50">{loading ? "Thinking…" : "Ask"}</button></div>{answer && <div className="mt-4 whitespace-pre-wrap rounded-2xl bg-slate-900 p-4 text-sm leading-6 text-slate-200">{answer}</div>}</section>
  </div>;
}

function localFallback(question: string, insights: Array<{ title: string; detail: string; action: string }>) {
  const q = question.toLowerCase();
  const relevant = insights.find((item) => q.includes("protein") ? item.title.includes("Protein") : q.includes("calor") || q.includes("eat") ? item.title.includes("Energy") : q.includes("weight") || q.includes("tež") ? item.title.includes("Weight") : q.includes("workout") || q.includes("train") || q.includes("bench") || q.includes("press") ? item.title.includes("Training") : false) || insights[0];
  return `${relevant.detail}\n\n${relevant.action}\n\nThis is based on the data currently logged in Mucipes. Add more recent sessions or weigh-ins if you want the trend to be more representative.`;
}
