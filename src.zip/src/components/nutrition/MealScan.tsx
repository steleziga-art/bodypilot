"use client";

import { ChangeEvent, useMemo, useState } from "react";

type Food = {
  id: number;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  mealId?: string;
};

type Meal = { id: string; name: string };

type ScannedItem = {
  name: string;
  grams: number;
  caloriesPer100: number;
  proteinPer100: number;
  carbsPer100: number;
  fatPer100: number;
  confidence?: number;
};

type ScanResponse = {
  items?: ScannedItem[];
  note?: string;
  error?: string;
};

function round1(value: number) {
  return Math.round(value * 10) / 10;
}

function itemTotals(item: ScannedItem) {
  const factor = Math.max(0, item.grams) / 100;
  return {
    calories: item.caloriesPer100 * factor,
    protein: item.proteinPer100 * factor,
    carbs: item.carbsPer100 * factor,
    fat: item.fatPer100 * factor,
  };
}

export default function MealScan({
  meals,
  defaultMealId,
  onAddFoods,
}: {
  meals: Meal[];
  defaultMealId?: string;
  onAddFoods: (foods: Food[]) => void;
}) {
  const [preview, setPreview] = useState<string | null>(null);
  const [imageData, setImageData] = useState<string | null>(null);
  const [items, setItems] = useState<ScannedItem[]>([]);
  const [mealId, setMealId] = useState(defaultMealId || meals[0]?.id || "breakfast");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const totals = useMemo(
    () =>
      items.reduce(
        (sum, item) => {
          const x = itemTotals(item);
          sum.calories += x.calories;
          sum.protein += x.protein;
          sum.carbs += x.carbs;
          sum.fat += x.fat;
          return sum;
        },
        { calories: 0, protein: 0, carbs: 0, fat: 0 }
      ),
    [items]
  );

  function chooseImage(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    setItems([]);
    setMessage("");
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setMessage("Choose an image file.");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setMessage("Use an image smaller than 8 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== "string") return;
      setImageData(reader.result);
      setPreview(reader.result);
    };
    reader.readAsDataURL(file);
  }

  async function scan() {
    if (!imageData) {
      setMessage("Add a meal photo first.");
      return;
    }
    setLoading(true);
    setMessage("");
    try {
      const response = await fetch("/api/meal-scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imageData }),
      });
      const data = (await response.json()) as ScanResponse;
      if (!response.ok) {
        setMessage(data.error || "Meal scan failed.");
        return;
      }
      const valid = (data.items || [])
        .filter((item) => item && item.name)
        .map((item) => ({
          ...item,
          grams: Math.max(0, Math.round(Number(item.grams) || 0)),
          caloriesPer100: Math.max(0, Number(item.caloriesPer100) || 0),
          proteinPer100: Math.max(0, Number(item.proteinPer100) || 0),
          carbsPer100: Math.max(0, Number(item.carbsPer100) || 0),
          fatPer100: Math.max(0, Number(item.fatPer100) || 0),
        }));
      setItems(valid);
      setMessage(
        valid.length
          ? data.note || "Review the estimated portions before adding them."
          : "No foods were confidently detected."
      );
    } catch {
      setMessage("Could not reach the meal scanner.");
    } finally {
      setLoading(false);
    }
  }

  function updateItem(index: number, patch: Partial<ScannedItem>) {
    setItems((current) =>
      current.map((item, itemIndex) => (itemIndex === index ? { ...item, ...patch } : item))
    );
  }

  function addToDiary() {
    if (!items.length) return;
    const base = Date.now();
    onAddFoods(
      items.map((item, index) => {
        const x = itemTotals(item);
        return {
          id: base + index,
          name: `${item.name} (${Math.round(item.grams)} g)`,
          calories: Math.round(x.calories),
          protein: round1(x.protein),
          carbs: round1(x.carbs),
          fat: round1(x.fat),
          mealId,
        };
      })
    );
    setMessage("Meal added to your diary. You can still edit each food there.");
  }

  return (
    <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-emerald-600">AI Meal Scan</p>
          <h3 className="mt-1 text-2xl font-black text-slate-950">Photo → editable estimate</h3>
          <p className="mt-2 max-w-xl text-sm leading-6 text-slate-500">
            Mucipes estimates foods and portions from the photo. The result is an estimate, so review grams and macros before adding it.
          </p>
        </div>
        <select
          value={mealId}
          onChange={(event) => setMealId(event.target.value)}
          className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-bold outline-none focus:border-emerald-500"
        >
          {meals.map((meal) => (
            <option key={meal.id} value={meal.id}>{meal.name}</option>
          ))}
        </select>
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-[0.8fr_1.2fr]">
        <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-4">
          {preview ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={preview} alt="Meal preview" className="max-h-72 w-full rounded-xl object-cover" />
          ) : (
            <div className="grid min-h-48 place-items-center text-center text-sm text-slate-400">
              Add a clear photo of the whole meal.
            </div>
          )}
          <label className="mt-3 block cursor-pointer rounded-xl bg-slate-950 px-4 py-3 text-center text-sm font-black text-white">
            Choose photo
            <input type="file" accept="image/*" className="hidden" onChange={chooseImage} />
          </label>
          <button
            type="button"
            onClick={scan}
            disabled={!imageData || loading}
            className="mt-2 w-full rounded-xl bg-emerald-500 px-4 py-3 text-sm font-black text-white disabled:cursor-not-allowed disabled:opacity-50"
          >
            {loading ? "Scanning…" : "Scan meal"}
          </button>
        </div>

        <div>
          {items.length > 0 ? (
            <div className="space-y-3">
              {items.map((item, index) => {
                const x = itemTotals(item);
                return (
                  <div key={`${item.name}-${index}`} className="rounded-2xl border border-slate-200 p-4">
                    <div className="flex items-start gap-3">
                      <div className="min-w-0 flex-1">
                        <input
                          value={item.name}
                          onChange={(event) => updateItem(index, { name: event.target.value })}
                          className="w-full bg-transparent font-black text-slate-950 outline-none"
                        />
                        <p className="mt-1 text-xs text-slate-500">
                          {Math.round(x.calories)} kcal · {round1(x.protein)} P · {round1(x.carbs)} C · {round1(x.fat)} F
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setItems((current) => current.filter((_, i) => i !== index))}
                        className="rounded-lg bg-slate-100 px-3 py-2 text-xs font-black text-slate-500"
                      >
                        Remove
                      </button>
                    </div>
                    <label className="mt-3 block text-xs font-bold text-slate-500">
                      Estimated grams
                      <input
                        type="number"
                        min={0}
                        step={5}
                        value={item.grams}
                        onChange={(event) => updateItem(index, { grams: Math.max(0, Number(event.target.value) || 0) })}
                        className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-base font-black outline-none focus:border-emerald-500"
                      />
                    </label>
                  </div>
                );
              })}

              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <ScanStat label="Calories" value={`${Math.round(totals.calories)} kcal`} />
                <ScanStat label="Protein" value={`${round1(totals.protein)} g`} />
                <ScanStat label="Carbs" value={`${round1(totals.carbs)} g`} />
                <ScanStat label="Fat" value={`${round1(totals.fat)} g`} />
              </div>
              <button type="button" onClick={addToDiary} className="w-full rounded-2xl bg-emerald-500 py-4 font-black text-white">
                Add estimated meal to diary
              </button>
            </div>
          ) : (
            <div className="grid min-h-64 place-items-center rounded-2xl border border-slate-200 bg-slate-50 p-6 text-center">
              <div>
                <p className="font-black text-slate-900">Your scan result appears here.</p>
                <p className="mt-2 text-sm leading-6 text-slate-500">You will be able to change the detected food names and grams before anything is saved.</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {message && <p className="mt-4 rounded-2xl bg-slate-100 px-4 py-3 text-sm font-semibold text-slate-600">{message}</p>}
    </section>
  );
}

function ScanStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-slate-50 p-3">
      <p className="text-[10px] font-black uppercase tracking-wider text-slate-400">{label}</p>
      <p className="mt-1 font-black text-slate-900">{value}</p>
    </div>
  );
}
