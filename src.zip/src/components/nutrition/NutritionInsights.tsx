"use client";

import { useMemo, useState } from "react";

type Goals = {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
};

type NutritionDay = {
  date: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
};

export default function NutritionInsights({
  caloriesEaten,
  proteinEaten,
  carbsEaten,
  fatEaten,
  goals,
  nutritionHistory,
  waterMl,
  setWaterMl,
}: {
  caloriesEaten: number;
  proteinEaten: number;
  carbsEaten: number;
  fatEaten: number;
  goals: Goals;
  nutritionHistory: NutritionDay[];
  waterMl: number;
  setWaterMl: React.Dispatch<React.SetStateAction<number>>;
}) {
  const [view, setView] = useState<"today" | "analytics">("today");
  const [range, setRange] = useState<7 | 30 | 90>(7);
  const waterGoal = 3000;

  const stats = useMemo(() => {
    const days = [...nutritionHistory]
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(-range);

    const average = (key: "calories" | "protein" | "carbs" | "fat") =>
      days.length
        ? Math.round(days.reduce((sum, day) => sum + day[key], 0) / days.length)
        : 0;

    const adherent = days.filter(
      (day) =>
        goals.calories > 0 &&
        Math.abs(day.calories - goals.calories) <= goals.calories * 0.1
    ).length;

    return {
      days,
      avgCalories: average("calories"),
      avgProtein: average("protein"),
      avgCarbs: average("carbs"),
      avgFat: average("fat"),
      adherence: days.length ? Math.round((adherent / days.length) * 100) : 0,
    };
  }, [nutritionHistory, range, goals.calories]);

  const calorieScore = Math.max(
    0,
    Math.min(100, Math.round(100 - (Math.abs(caloriesEaten - goals.calories) / Math.max(1, goals.calories)) * 100))
  );
  const proteinScore = Math.max(0, Math.min(100, Math.round((proteinEaten / Math.max(1, goals.protein)) * 100)));
  const hydrationScore = Math.max(0, Math.min(100, Math.round((waterMl / waterGoal) * 100)));
  const score = Math.round((calorieScore + proteinScore + hydrationScore) / 3);

  const macros = [
    { label: "Protein", value: proteinEaten, goal: goals.protein, unit: "g" },
    { label: "Carbs", value: carbsEaten, goal: goals.carbs, unit: "g" },
    { label: "Fat", value: fatEaten, goal: goals.fat, unit: "g" },
  ];

  return (
    <section className="mt-8 overflow-hidden rounded-[2rem] border border-slate-200 bg-white shadow-sm">
      <div className="bg-slate-950 p-6 text-white">
        <div className="flex flex-wrap items-start justify-between gap-5">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.18em] text-emerald-400">Nutrition 3.0</p>
            <h2 className="mt-2 text-3xl font-black">Fuel the plan.</h2>
            <p className="mt-2 max-w-xl text-sm text-slate-300">
              One place for today&apos;s targets, hydration and your longer-term nutrition consistency.
            </p>
          </div>
          <div className="flex rounded-2xl bg-white/10 p-1">
            <button onClick={() => setView("today")} className={`rounded-xl px-4 py-2 text-sm font-black ${view === "today" ? "bg-white text-slate-950" : "text-slate-300"}`}>Today</button>
            <button onClick={() => setView("analytics")} className={`rounded-xl px-4 py-2 text-sm font-black ${view === "analytics" ? "bg-white text-slate-950" : "text-slate-300"}`}>Analytics</button>
          </div>
        </div>

        <div className="mt-6 grid gap-3 sm:grid-cols-4">
          <Metric label="Nutrition score" value={`${score}/100`} />
          <Metric label="Calories" value={`${Math.round(caloriesEaten)} / ${goals.calories}`} />
          <Metric label="Protein" value={`${Math.round(proteinEaten)} / ${goals.protein} g`} />
          <Metric label="Water" value={`${(waterMl / 1000).toFixed(1)} / 3.0 L`} />
        </div>
      </div>

      {view === "today" ? (
        <div className="grid gap-5 p-6 lg:grid-cols-[1.15fr_.85fr]">
          <div>
            <p className="text-xs font-black uppercase tracking-widest text-slate-400">Macro progress</p>
            <div className="mt-4 space-y-4">
              {macros.map((macro) => {
                const pct = Math.min(100, Math.round((macro.value / Math.max(1, macro.goal)) * 100));
                return (
                  <div key={macro.label}>
                    <div className="mb-2 flex justify-between text-sm">
                      <span className="font-black">{macro.label}</span>
                      <span className="text-slate-500">{Math.round(macro.value)} / {macro.goal} {macro.unit}</span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full rounded-full bg-emerald-500" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="rounded-3xl bg-slate-50 p-5">
            <div className="flex items-center justify-between gap-3">
              <div><p className="text-xs font-black uppercase tracking-widest text-sky-600">Hydration</p><p className="mt-1 text-2xl font-black">{waterMl} ml</p></div>
              <button onClick={() => setWaterMl(0)} className="text-xs font-black text-slate-400 hover:text-slate-700">Reset</button>
            </div>
            <div className="mt-4 h-2 overflow-hidden rounded-full bg-slate-200">
              <div className="h-full rounded-full bg-sky-500" style={{ width: `${hydrationScore}%` }} />
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2">
              {[250, 500, 750].map((ml) => (
                <button key={ml} onClick={() => setWaterMl((value) => value + ml)} className="rounded-xl bg-white px-2 py-3 text-xs font-black shadow-sm hover:bg-slate-100">+{ml} ml</button>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="p-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div><p className="text-xs font-black uppercase tracking-widest text-emerald-600">Analytics</p><h3 className="mt-1 text-2xl font-black">Consistency over time</h3></div>
            <div className="flex rounded-xl bg-slate-100 p-1">
              {([7, 30, 90] as const).map((days) => (
                <button key={days} onClick={() => setRange(days)} className={`rounded-lg px-3 py-2 text-xs font-black ${range === days ? "bg-white shadow-sm" : "text-slate-500"}`}>{days}D</button>
              ))}
            </div>
          </div>

          <div className="mt-5 grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
            <AnalyticsMetric label="Avg calories" value={stats.days.length ? `${stats.avgCalories}` : "—"} detail={`Target ${goals.calories}`} />
            <AnalyticsMetric label="Avg protein" value={stats.days.length ? `${stats.avgProtein}g` : "—"} detail={`Target ${goals.protein}g`} />
            <AnalyticsMetric label="Avg carbs" value={stats.days.length ? `${stats.avgCarbs}g` : "—"} detail={`Target ${goals.carbs}g`} />
            <AnalyticsMetric label="Avg fat" value={stats.days.length ? `${stats.avgFat}g` : "—"} detail={`Target ${goals.fat}g`} />
            <AnalyticsMetric label="Adherence" value={stats.days.length ? `${stats.adherence}%` : "—"} detail="Within ±10% calories" />
          </div>

          <div className="mt-5 rounded-3xl bg-slate-50 p-5">
            <div className="flex items-center justify-between gap-3">
              <div><p className="text-xs font-black uppercase tracking-widest text-slate-400">Logged days</p><p className="mt-1 text-xl font-black">{stats.days.length} of last {range} days</p></div>
              <span className="rounded-full bg-white px-3 py-1 text-xs font-black text-slate-500">Local history</span>
            </div>
            <div className="mt-5 flex h-28 items-end gap-1">
              {stats.days.length ? stats.days.map((day) => {
                const pct = Math.max(8, Math.min(100, (day.calories / Math.max(1, goals.calories)) * 75));
                return <div key={day.date} title={`${day.date}: ${day.calories} kcal`} className="min-w-1 flex-1 rounded-t bg-emerald-500/80" style={{ height: `${pct}%` }} />;
              }) : <div className="flex h-full w-full items-center justify-center text-sm text-slate-400">Log food for a few days to build your trend.</div>}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div className="rounded-2xl bg-white/10 p-4"><p className="text-xs font-bold text-slate-400">{label}</p><p className="mt-1 text-xl font-black">{value}</p></div>;
}

function AnalyticsMetric({ label, value, detail }: { label: string; value: string; detail: string }) {
  return <div className="rounded-2xl border border-slate-200 bg-white p-4"><p className="text-xs font-black uppercase tracking-wider text-slate-400">{label}</p><p className="mt-2 text-2xl font-black">{value}</p><p className="mt-1 text-xs text-slate-500">{detail}</p></div>;
}
