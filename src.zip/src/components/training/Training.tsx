"use client";

import { useEffect, useMemo, useState } from "react";
import { defaultExercises } from "./exercises";
import LyftaImport from "./LyftaImport";
import { loadCloudData, saveCloudData, deleteCloudData } from "@/lib/supabase/storage";
import type {
  ActiveWorkout,
  Exercise,
  MuscleGroup,
  SavedWorkout,
  WorkoutExercise,
  WorkoutHistoryEntry,
  WorkoutSet,
} from "./types";

type TrainingTab =
  | "workout"
  | "saved"
  | "history"
  | "exercises"
  | "analytics";

const muscleGroups: MuscleGroup[] = [
  "Chest",
  "Back",
  "Shoulders",
  "Biceps",
  "Triceps",
  "Quads",
  "Hamstrings",
  "Glutes",
  "Calves",
  "Abs",
  "Other",
];

const ACTIVE_KEY = "bodypilot-active-workout";
const SAVED_KEY = "bodypilot-saved-workouts";
const HISTORY_KEY = "bodypilot-workout-history";
const CUSTOM_EXERCISES_KEY = "bodypilot-custom-exercises";
const WORKOUT_NOTES_KEY = "bodypilot-workout-notes";
const EXERCISE_NOTES_KEY = "bodypilot-exercise-notes";
const SET_TYPES_KEY = "bodypilot-set-types";
const ROUTINE_TARGETS_KEY = "bodypilot-routine-targets";
const SUPERSETS_KEY = "bodypilot-supersets";
const REST_PREFS_KEY = "bodypilot-rest-prefs";
const EXERCISE_FAVORITES_KEY = "bodypilot-exercise-favorites";
const RECENT_EXERCISES_KEY = "bodypilot-recent-exercises";



function formatStoredWeight(kg: number, units: "metric" | "imperial") {
  if (units === "imperial") {
    const lb = Math.round(kg * 2.2046226218 * 10) / 10;
    return `${lb} lb`;
  }
  return `${kg} kg`;
}

function formatStoredVolume(kg: number, units: "metric" | "imperial") {
  const value = units === "imperial" ? kg * 2.2046226218 : kg;
  return `${Math.round(value).toLocaleString()} ${units === "imperial" ? "lb" : "kg"}`;
}

function exerciseBadge(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
}


function exerciseMediaSlug(name: string) {
  const n = name.toLowerCase();

  if (n.includes("incline") && n.includes("bench")) return "incline-bench-press";
  if (n.includes("bench press")) return "bench-press";
  if (n.includes("chest press")) return "chest-press";
  if (n.includes("chest fly") || n.includes("pec deck")) return "chest-fly";
  if (n.includes("shoulder press") || n.includes("overhead press")) return "shoulder-press";
  if (n.includes("lateral raise")) return "lateral-raise";
  if (n.includes("lat pulldown") || n.includes("pulldown")) return "lat-pulldown";
  if (n.includes("seated row") || n.includes("cable row")) return "seated-row";
  if (n.includes("squat")) return "squat";
  if (n.includes("curl")) return "biceps-curl";

  return null;
}

function ExerciseMedia({
  name,
  compact = false,
}: {
  name: string;
  compact?: boolean;
}) {
  const slug = exerciseMediaSlug(name);

  if (!slug) {
    return (
      <div
        className={`flex items-center justify-center overflow-hidden rounded-2xl border border-slate-200 bg-white ${
          compact ? "h-12 w-12" : "min-h-[210px] w-full"
        }`}
      >
        <div className="text-center">
          <div
            className={`mx-auto flex items-center justify-center rounded-full border border-slate-300 bg-white font-black tracking-wider text-green-400 ${
              compact ? "h-9 w-9 text-[10px]" : "h-20 w-20 text-xl"
            }`}
          >
            {exerciseBadge(name)}
          </div>

          {!compact && (
            <p className="mt-3 text-xs text-zinc-600">
              Exercise illustration coming soon
            </p>
          )}
        </div>
      </div>
    );
  }

  return (
    <div
      className={`overflow-hidden rounded-2xl border border-slate-200 bg-white ${
        compact ? "h-12 w-12" : "w-full"
      }`}
    >
      <img
        src={`/exercises/${slug}.svg`}
        alt={`${name} exercise demonstration`}
        className={`h-full w-full object-cover ${
          compact ? "" : "min-h-[210px]"
        }`}
      />
    </div>
  );
}

function exerciseInstructions(name: string) {
  const n = name.toLowerCase();

  if (n.includes("press")) {
    return "Control the lowering phase, keep a stable position and press through a comfortable full range of motion.";
  }

  if (n.includes("row")) {
    return "Keep your torso stable, pull with the elbows and control the weight back to the start.";
  }

  if (n.includes("curl")) {
    return "Keep the upper arm controlled, curl without swinging and lower the weight slowly.";
  }

  if (n.includes("raise")) {
    return "Use controlled reps, avoid momentum and stop at a comfortable shoulder position.";
  }

  if (n.includes("squat")) {
    return "Brace before each rep, keep a stable foot position and use a controlled depth you can maintain.";
  }

  if (n.includes("deadlift") || n.includes("rdl")) {
    return "Brace the trunk, keep the load close and hinge through the hips while maintaining control.";
  }

  return "Use a stable setup, controlled tempo and a comfortable full range of motion.";
}

export default function Training() {
  const [displayUnits, setDisplayUnits] = useState<"metric" | "imperial">(() => {
    if (typeof window === "undefined") return "metric";
    try {
      const raw = localStorage.getItem("bodypilot-settings");
      return raw && JSON.parse(raw)?.units === "imperial" ? "imperial" : "metric";
    } catch {
      return "metric";
    }
  });

  useEffect(() => {
    const syncDisplaySettings = () => {
      try {
        const raw = localStorage.getItem("bodypilot-settings");
        setDisplayUnits(raw && JSON.parse(raw)?.units === "imperial" ? "imperial" : "metric");
      } catch {
        setDisplayUnits("metric");
      }
    };
    window.addEventListener("mucipes-settings-changed", syncDisplaySettings);
    window.addEventListener("storage", syncDisplaySettings);
    return () => {
      window.removeEventListener("mucipes-settings-changed", syncDisplaySettings);
      window.removeEventListener("storage", syncDisplaySettings);
    };
  }, []);

  const [activeTab, setActiveTab] =
    useState<TrainingTab>("workout");

  const [activeWorkout, setActiveWorkout] =
    useState<ActiveWorkout | null>(null);

  const [savedWorkouts, setSavedWorkouts] =
    useState<SavedWorkout[]>([]);

  const [history, setHistory] =
    useState<WorkoutHistoryEntry[]>([]);

  const [customExercises, setCustomExercises] =
    useState<Exercise[]>([]);

  const [loaded, setLoaded] = useState(false);
  const [cloudReady, setCloudReady] = useState(false);

  useEffect(() => {
    try {
      const active = localStorage.getItem(ACTIVE_KEY);
      const saved = localStorage.getItem(SAVED_KEY);
      const workoutHistory =
        localStorage.getItem(HISTORY_KEY);
      const custom =
        localStorage.getItem(CUSTOM_EXERCISES_KEY);

      if (active) {
        setActiveWorkout(JSON.parse(active));
      }

      if (saved) {
        const parsed = JSON.parse(saved);

        if (Array.isArray(parsed)) {
          setSavedWorkouts(parsed);
        }
      }

      if (workoutHistory) {
        const parsed = JSON.parse(workoutHistory);

        if (Array.isArray(parsed)) {
          setHistory(parsed);
        }
      }

      if (custom) {
        const parsed = JSON.parse(custom);

        if (Array.isArray(parsed)) {
          setCustomExercises(parsed);
        }
      }
    } catch (error) {
      console.error(
        "Could not load training data:",
        error
      );
    } finally {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    if (!loaded) return;

    let cancelled = false;
    async function hydrateTrainingFromCloud() {
      const [cloudActive, cloudSaved, cloudHistory, cloudCustom] = await Promise.all([
        loadCloudData<ActiveWorkout>("active_workout"),
        loadCloudData<SavedWorkout[]>("saved_workouts"),
        loadCloudData<WorkoutHistoryEntry[]>("workout_history"),
        loadCloudData<Exercise[]>("custom_exercises"),
      ]);
      if (cancelled) return;
      if (cloudActive) setActiveWorkout(cloudActive);
      if (Array.isArray(cloudSaved)) setSavedWorkouts(cloudSaved);
      if (Array.isArray(cloudHistory)) setHistory(cloudHistory);
      if (Array.isArray(cloudCustom)) setCustomExercises(cloudCustom);
      setCloudReady(true);
    }
    void hydrateTrainingFromCloud();
    return () => { cancelled = true; };
  }, [loaded]);

  useEffect(() => {
    if (!loaded) {
      return;
    }

    if (activeWorkout) {
      localStorage.setItem(
        ACTIVE_KEY,
        JSON.stringify(activeWorkout)
      );
    } else {
      localStorage.removeItem(ACTIVE_KEY);
    }

    localStorage.setItem(
      SAVED_KEY,
      JSON.stringify(savedWorkouts)
    );

    localStorage.setItem(
      HISTORY_KEY,
      JSON.stringify(history)
    );

    localStorage.setItem(
      CUSTOM_EXERCISES_KEY,
      JSON.stringify(customExercises)
    );

    if (cloudReady) {
      if (activeWorkout) void saveCloudData("active_workout", activeWorkout);
      else void deleteCloudData("active_workout");
      void Promise.all([
        saveCloudData("saved_workouts", savedWorkouts),
        saveCloudData("workout_history", history),
        saveCloudData("custom_exercises", customExercises),
      ]);
    }
  }, [
    activeWorkout,
    savedWorkouts,
    history,
    customExercises,
    loaded,
    cloudReady,
  ]);

  const allExercises = useMemo(
    () => [...defaultExercises, ...customExercises],
    [customExercises]
  );

  function startEmptyWorkout() {
    if (activeWorkout) {
      return;
    }

    setActiveWorkout({
      id: makeId(),
      name: "Workout",
      startedAt: new Date().toISOString(),
      exercises: [],
    });
  }

  function startSavedWorkout(
    savedWorkout: SavedWorkout
  ) {
    if (activeWorkout) {
      return;
    }

    const exercises: WorkoutExercise[] =
      savedWorkout.exercises.map((exercise) => ({
        id: makeId(),
        exerciseId: exercise.exerciseId,
        exerciseName: exercise.exerciseName,
        sets: Array.from(
          { length: exercise.defaultSets },
          () => createEmptySet()
        ),
      }));

    setActiveWorkout({
      id: makeId(),
      name: savedWorkout.name,
      startedAt: new Date().toISOString(),
      exercises,
    });

    setActiveTab("workout");
  }

  function finishWorkout() {
    if (!activeWorkout) {
      return;
    }

    if (activeWorkout.exercises.length === 0) {
      const confirmed = window.confirm(
        "This workout has no exercises. Discard it?"
      );

      if (confirmed) {
        setActiveWorkout(null);
      }

      return;
    }

    const finishedAt = new Date();

    const historyEntry: WorkoutHistoryEntry = {
      id: activeWorkout.id,
      name: activeWorkout.name.trim() || "Workout",
      startedAt: activeWorkout.startedAt,
      finishedAt: finishedAt.toISOString(),
      durationSeconds: Math.max(
        0,
        Math.round(
          (finishedAt.getTime() -
            new Date(
              activeWorkout.startedAt
            ).getTime()) /
            1000
        )
      ),
      exercises: activeWorkout.exercises.map(
        (exercise) => ({
          ...exercise,
          sets: exercise.sets.filter(
            (set) =>
              set.completed ||
              set.weight > 0 ||
              set.reps > 0
          ),
        })
      ),
    };

    setHistory((current) => [
      historyEntry,
      ...current,
    ]);

    setActiveWorkout(null);
    setActiveTab("history");
  }

  function discardWorkout() {
    if (!activeWorkout) {
      return;
    }

    const confirmed = window.confirm(
      "Discard the current workout?"
    );

    if (confirmed) {
      setActiveWorkout(null);
    }
  }

  function saveCurrentWorkout() {
    if (
      !activeWorkout ||
      activeWorkout.exercises.length === 0
    ) {
      return;
    }

    const name = window.prompt(
      "Saved workout name:",
      activeWorkout.name === "Workout"
        ? ""
        : activeWorkout.name
    );

    if (!name?.trim()) {
      return;
    }

    const newSavedWorkout: SavedWorkout = {
      id: makeId(),
      name: name.trim(),
      createdAt: new Date().toISOString(),
      exercises: activeWorkout.exercises.map(
        (exercise) => ({
          exerciseId: exercise.exerciseId,
          exerciseName: exercise.exerciseName,
          defaultSets: Math.max(
            exercise.sets.length,
            1
          ),
        })
      ),
    };

    setSavedWorkouts((current) => [
      ...current,
      newSavedWorkout,
    ]);
  }

  function deleteSavedWorkout(id: string) {
    setSavedWorkouts((current) =>
      current.filter(
        (workout) => workout.id !== id
      )
    );
  }

  function deleteHistoryEntry(id: string) {
    const confirmed = window.confirm(
      "Delete this workout from history?"
    );

    if (!confirmed) {
      return;
    }

    setHistory((current) =>
      current.filter(
        (workout) => workout.id !== id
      )
    );
  }

  function addCustomExercise(
    exercise: Exercise
  ) {
    setCustomExercises((current) => [
      ...current,
      exercise,
    ]);
  }

  function deleteCustomExercise(id: string) {
    setCustomExercises((current) =>
      current.filter(
        (exercise) => exercise.id !== id
      )
    );
  }

  return (
    <>
      <div>
      <section className="mb-5 grid gap-3 sm:grid-cols-4">
        <WorkoutV2Chip title="Previous sets" detail="Auto-filled history" />
        <WorkoutV2Chip title="PR detection" detail="Best-set tracking" />
        <WorkoutV2Chip title="RIR" detail="Optional per exercise" />
        <WorkoutV2Chip title="Volume" detail="Live workout total" />
      </section>

      <section className="mb-6 overflow-hidden rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
        <div className="flex flex-wrap items-end justify-between gap-5">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-emerald-600">
              Mucipes Workout
            </p>
            <h1 className="mt-2 text-3xl font-black tracking-tight text-slate-950">
              Train. Log. Progress.
            </h1>
            <p className="mt-2 max-w-xl text-sm leading-6 text-slate-500">
              Your routines, live workout, exercise library and progress in one place.
            </p>
          </div>
          {!activeWorkout && (
            <button
              onClick={startEmptyWorkout}
              className="rounded-2xl bg-emerald-500 px-5 py-3 text-sm font-black text-white shadow-sm transition hover:bg-emerald-600"
            >
              Start Workout
            </button>
          )}
        </div>

        <div className="mt-6 grid grid-cols-3 gap-3">
          <WorkoutHeroStat label="Workouts" value={history.length} />
          <WorkoutHeroStat
            label="Routines"
            value={savedWorkouts.length}
          />
          <WorkoutHeroStat
            label="Status"
            value={activeWorkout ? "Active" : "Ready"}
          />
        </div>
      </section>

        <p className="text-sm font-semibold tracking-widest text-green-400">
          TRAINING
        </p>

        <h1 className="mt-2 text-4xl font-bold">
          Training
        </h1>

        <p className="mt-2 text-slate-500">
          Build workouts, track every set and
          see your training history.
        </p>
      </div>

      <div className="mt-8 flex flex-wrap gap-2 rounded-2xl border border-slate-200 bg-white p-2">
        <TabButton
          name="Workout"
          tab="workout"
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />

        <TabButton
          name="Saved Workouts"
          tab="saved"
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />

        <TabButton
          name="History"
          tab="history"
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />

        <TabButton
          name="Exercises"
          tab="exercises"
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />

        <TabButton
          name="Analytics"
          tab="analytics"
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />
      </div>

      {activeTab === "workout" && (
        <WorkoutTab
          activeWorkout={activeWorkout}
          setActiveWorkout={setActiveWorkout}
          exercises={allExercises}
          history={history}
          savedWorkouts={savedWorkouts}
          startEmptyWorkout={startEmptyWorkout}
          startSavedWorkout={startSavedWorkout}
          finishWorkout={finishWorkout}
          discardWorkout={discardWorkout}
          saveCurrentWorkout={saveCurrentWorkout}
          displayUnits={displayUnits}
        />
      )}

      {activeTab === "saved" && (
        <SavedWorkoutsTab
          savedWorkouts={savedWorkouts}
          setSavedWorkouts={setSavedWorkouts}
          exercises={allExercises}
          activeWorkout={activeWorkout}
          startSavedWorkout={startSavedWorkout}
          deleteSavedWorkout={deleteSavedWorkout}
          setActiveTab={setActiveTab}
        />
      )}

      {activeTab === "history" && (
        <div className="space-y-5">
          <LyftaImport
            exercises={allExercises}
            onImport={(entries) => {
              setHistory((current) => {
                const existing = new Set(current.map((workout) => workout.id));
                const incoming = entries.filter((workout) => !existing.has(workout.id));
                return [...incoming, ...current].sort(
                  (a, b) => new Date(b.finishedAt).getTime() - new Date(a.finishedAt).getTime()
                );
              });
            }}
          />
          <HistoryTab
            history={history}
            deleteHistoryEntry={deleteHistoryEntry}
            displayUnits={displayUnits}
          />
        </div>
      )}

      {activeTab === "exercises" && (
        <ExercisesTab
          exercises={allExercises}
          history={history}
          displayUnits={displayUnits}
          customExercises={customExercises}
          addCustomExercise={addCustomExercise}
          deleteCustomExercise={
            deleteCustomExercise
          }
        />
      )}

      {activeTab === "analytics" && (
        <AnalyticsTab history={history} exercises={allExercises} displayUnits={displayUnits} />
      )}
    </>
  );
}

function WorkoutTab({
  activeWorkout,
  setActiveWorkout,
  exercises,
  history,
  savedWorkouts,
  startEmptyWorkout,
  startSavedWorkout,
  finishWorkout,
  discardWorkout,
  saveCurrentWorkout,
  displayUnits,
}: {
  activeWorkout: ActiveWorkout | null;
  setActiveWorkout: React.Dispatch<
    React.SetStateAction<ActiveWorkout | null>
  >;
  exercises: Exercise[];
  history: WorkoutHistoryEntry[];
  savedWorkouts: SavedWorkout[];
  startEmptyWorkout: () => void;
  startSavedWorkout: (
    workout: SavedWorkout
  ) => void;
  finishWorkout: () => void;
  discardWorkout: () => void;
  saveCurrentWorkout: () => void;
  displayUnits: "metric" | "imperial";
}) {
  const [restSecondsLeft, setRestSecondsLeft] = useState(0);
  const [restTimerEnabled, setRestTimerEnabled] = useState(true);
  const [restDuration, setRestDuration] = useState(120);

  useEffect(() => {
    if (restSecondsLeft <= 0) return;
    const timer = window.setInterval(() => {
      setRestSecondsLeft((current) => Math.max(0, current - 1));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [restSecondsLeft]);

  const [showExercisePicker, setShowExercisePicker] =
    useState(false);

  const [search, setSearch] = useState("");

  const [muscleFilter, setMuscleFilter] =
    useState<MuscleGroup | "All">("All");

  const [elapsedSeconds, setElapsedSeconds] =
    useState(0);

  const [workoutNote, setWorkoutNote] =
    useState("");

  const [showRirByExercise, setShowRirByExercise] =
    useState<Record<string, boolean>>({});

  const [openDetailsByExercise, setOpenDetailsByExercise] =
    useState<Record<string, boolean>>({});

  const [exerciseNotes, setExerciseNotes] =
    useState<Record<string, string>>({});

  const [setTypes, setSetTypes] = useState<Record<string, "N" | "W" | "D" | "F">>(() => {
    if (typeof window === "undefined") return {};
    try { const raw = localStorage.getItem(SET_TYPES_KEY); return raw ? JSON.parse(raw) : {}; }
    catch { return {}; }
  });
  const [replaceExerciseId, setReplaceExerciseId] = useState<string | null>(null);
  const [replaceSearch, setReplaceSearch] = useState("");
  const [showFinishReview, setShowFinishReview] = useState(false);
  const [sessionFeeling, setSessionFeeling] = useState(4);
  const [collapsedExercises, setCollapsedExercises] = useState<Record<string, boolean>>({});
  const [supersetGroups, setSupersetGroups] = useState<Record<string, string>>(() => {
    if (typeof window === "undefined") return {};
    try { const raw = localStorage.getItem(SUPERSETS_KEY); return raw ? JSON.parse(raw) : {}; } catch { return {}; }
  });
  const [paused, setPaused] = useState(false);
  const [pauseStartedAt, setPauseStartedAt] = useState<number | null>(null);
  const [pausedTotal, setPausedTotal] = useState(0);
  const [unit, setUnit] = useState<"kg" | "lb">(displayUnits === "imperial" ? "lb" : "kg");
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    setUnit(displayUnits === "imperial" ? "lb" : "kg");
  }, [displayUnits]);

  const kgToLb = (kg: number) => Math.round(kg * 2.2046226218 * 10) / 10;
  const lbToKg = (lb: number) => Math.round((lb / 2.2046226218) * 100) / 100;
  const displayWeight = (kg: number) => unit === "lb" ? kgToLb(kg) : kg;
  const weightLabel = unit;



  useEffect(() => {
    let cancelled = false;
    async function hydrateWorkoutPreferences() {
      const [cloudSetTypes, cloudSupersets, cloudExerciseNotes] = await Promise.all([
        loadCloudData<Record<string, "N" | "W" | "D" | "F">>("set_types"),
        loadCloudData<Record<string, string>>("supersets"),
        loadCloudData<Record<string, string>>("exercise_notes"),
      ]);
      if (cancelled) return;
      if (cloudSetTypes) setSetTypes(cloudSetTypes);
      if (cloudSupersets) setSupersetGroups(cloudSupersets);
      if (cloudExerciseNotes) setExerciseNotes(cloudExerciseNotes);
    }
    void hydrateWorkoutPreferences();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    localStorage.setItem(SET_TYPES_KEY, JSON.stringify(setTypes));
    void saveCloudData("set_types", setTypes);
  }, [setTypes]);

  useEffect(() => {
    localStorage.setItem(SUPERSETS_KEY, JSON.stringify(supersetGroups));
    void saveCloudData("supersets", supersetGroups);
  }, [supersetGroups]);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 2200);
    return () => window.clearTimeout(id);
  }, [toast]);


  useEffect(() => {
    if (!activeWorkout) {
      setElapsedSeconds(0);
      return;
    }

    const updateTimer = () => {
      if (paused) return;
      const startedAt = new Date(activeWorkout.startedAt).getTime();
      setElapsedSeconds(
        Math.max(0, Math.floor((Date.now() - startedAt - pausedTotal) / 1000))
      );
    };

    updateTimer();

    const interval = window.setInterval(
      updateTimer,
      1000
    );

    return () => {
      window.clearInterval(interval);
    };
  }, [activeWorkout, paused, pausedTotal]);

  useEffect(() => {
    try {
      const savedNotes =
        localStorage.getItem(EXERCISE_NOTES_KEY);

      if (savedNotes) {
        const parsed = JSON.parse(savedNotes);

        if (
          parsed &&
          typeof parsed === "object" &&
          !Array.isArray(parsed)
        ) {
          setExerciseNotes(parsed);
        }
      }
    } catch (error) {
      console.error(
        "Could not load exercise notes:",
        error
      );
    }
  }, []);

  useEffect(() => {
    if (!activeWorkout) {
      setWorkoutNote("");
      return;
    }

    try {
      const savedWorkoutNotes =
        localStorage.getItem(WORKOUT_NOTES_KEY);

      if (!savedWorkoutNotes) {
        setWorkoutNote("");
        return;
      }

      const parsed = JSON.parse(
        savedWorkoutNotes
      ) as Record<string, string>;

      setWorkoutNote(
        parsed[activeWorkout.id] ?? ""
      );
    } catch (error) {
      console.error(
        "Could not load workout note:",
        error
      );
    }
  }, [activeWorkout?.id]);

  function saveWorkoutNote(value: string) {
    setWorkoutNote(value);

    if (!activeWorkout) {
      return;
    }

    try {
      const saved =
        localStorage.getItem(WORKOUT_NOTES_KEY);

      const parsed: Record<string, string> =
        saved ? JSON.parse(saved) : {};

      if (value.trim()) {
        parsed[activeWorkout.id] = value;
      } else {
        delete parsed[activeWorkout.id];
      }

      localStorage.setItem(
        WORKOUT_NOTES_KEY,
        JSON.stringify(parsed)
      );
      void saveCloudData("workout_notes", parsed);
    } catch (error) {
      console.error(
        "Could not save workout note:",
        error
      );
    }
  }

  function saveExerciseNote(
    exerciseId: string,
    value: string
  ) {
    const next = {
      ...exerciseNotes,
      [exerciseId]: value,
    };

    if (!value.trim()) {
      delete next[exerciseId];
    }

    setExerciseNotes(next);

    localStorage.setItem(
      EXERCISE_NOTES_KEY,
      JSON.stringify(next)
    );
    void saveCloudData("exercise_notes", next);
  }

  if (!activeWorkout) {
    return (
      <div className="mt-8">
        <section className="rounded-3xl border border-slate-200 bg-white p-8">
          <p className="text-sm font-semibold tracking-widest text-green-400">
            READY TO TRAIN
          </p>

          <h2 className="mt-2 text-3xl font-bold">
            Start a workout
          </h2>

          <p className="mt-2 max-w-2xl text-slate-500">
            Start from scratch or use one of
            your saved workout templates.
          </p>

          <button
            onClick={startEmptyWorkout}
            className="mt-7 rounded-xl bg-green-400 px-6 py-3 font-semibold text-black transition hover:bg-green-300"
          >
            + Start empty workout
          </button>
        </section>

        {savedWorkouts.length > 0 && (
          <section className="mt-6 rounded-3xl border border-slate-200 bg-white p-7">
            <h2 className="text-2xl font-semibold">
              Saved workouts
            </h2>

            <div className="mt-5 grid gap-4 md:grid-cols-2">
              {savedWorkouts.map((workout) => (
                <button
                  key={workout.id}
                  onClick={() =>
                    startSavedWorkout(workout)
                  }
                  className="rounded-2xl border border-slate-200 bg-white p-5 text-left transition hover:border-green-400/60"
                >
                  <p className="font-semibold">
                    {workout.name}
                  </p>

                  <p className="mt-1 text-sm text-slate-400">
                    {workout.exercises.length}{" "}
                    exercises
                  </p>
                </button>
              ))}
            </div>
          </section>
        )}
      </div>
    );
  }

  const filteredExercises = exercises.filter(
    (exercise) => {
      const matchesSearch =
        exercise.name
          .toLowerCase()
          .includes(search.toLowerCase());

      const matchesMuscle =
        muscleFilter === "All" ||
        exercise.muscleGroup === muscleFilter;

      return matchesSearch && matchesMuscle;
    }
  );

  function changeWorkoutName(name: string) {
    setActiveWorkout((current) =>
      current
        ? {
            ...current,
            name,
          }
        : current
    );
  }

  function addExercise(exercise: Exercise) {
    const newExercise: WorkoutExercise = {
      id: makeId(),
      exerciseId: exercise.id,
      exerciseName: exercise.name,
      sets: [createEmptySet()],
    };

    setActiveWorkout((current) =>
      current
        ? {
            ...current,
            exercises: [
              ...current.exercises,
              newExercise,
            ],
          }
        : current
    );

    setShowExercisePicker(false);
    setSearch("");
  }

  function removeExercise(
    workoutExerciseId: string
  ) {
    setActiveWorkout((current) =>
      current
        ? {
            ...current,
            exercises:
              current.exercises.filter(
                (exercise) =>
                  exercise.id !==
                  workoutExerciseId
              ),
          }
        : current
    );
  }

  function replaceExercise(workoutExerciseId: string, replacement: Exercise) {
    setActiveWorkout((current) => {
      if (!current) return current;
      return {
        ...current,
        exercises: current.exercises.map((item) =>
          item.id === workoutExerciseId
            ? {
                ...item,
                exerciseId: replacement.id,
                exerciseName: replacement.name,
              }
            : item
        ),
      };
    });
    setReplaceExerciseId(null);
    setReplaceSearch("");
  }

  function cycleSetType(setId: string) {
    const order: Array<"N" | "W" | "D" | "F"> = ["N", "W", "D", "F"];
    setSetTypes((current) => {
      const now = current[setId] ?? "N";
      const next = order[(order.indexOf(now) + 1) % order.length];
      return { ...current, [setId]: next };
    });
  }

  function togglePause() {
    if (!activeWorkout) return;
    if (!paused) {
      setPaused(true);
      setPauseStartedAt(Date.now());
    } else {
      if (pauseStartedAt) setPausedTotal((v) => v + (Date.now() - pauseStartedAt));
      setPaused(false);
      setPauseStartedAt(null);
    }
  }

  function toggleCollapse(id: string) {
    setCollapsedExercises((current) => ({ ...current, [id]: !current[id] }));
  }

  function toggleSuperset(id: string) {
    setSupersetGroups((current) => {
      const currentGroup = current[id];
      if (currentGroup) {
        const next = { ...current };
        delete next[id];
        return next;
      }
      const other = activeWorkout?.exercises.find((e) => e.id !== id && !current[e.id]);
      if (!other) return current;
      const group = `SS-${Date.now()}`;
      return { ...current, [id]: group, [other.id]: group };
    });
  }

  function quickWeight(workoutExerciseId: string, setId: string, deltaKg: number) {
    setActiveWorkout((current) => current ? {
      ...current,
      exercises: current.exercises.map((exercise) => exercise.id !== workoutExerciseId ? exercise : {
        ...exercise,
        sets: exercise.sets.map((set) => set.id !== setId ? set : {
          ...set,
          weight: Math.max(0, Math.round((set.weight + deltaKg) * 2) / 2)
        })
      })
    } : current);
  }

  function progressiveSuggestion(exerciseId: string, setIndex: number) {
    const previous = history
      .flatMap((workout) => workout.exercises)
      .find((exercise) => exercise.exerciseId === exerciseId);
    const set = previous?.sets[setIndex];
    if (!set || !set.weight || !set.reps) return null;
    const suggestedKg = set.reps >= 12 ? set.weight + 2.5 : set.weight;
    // Historical performances stay in the unit in which the old data was stored.
    // The global lb preference applies to new/current workout entry only.
    if (set.reps >= 12) return { text: `Try ${suggestedKg} kg`, tone: "up" };
    if (set.reps <= 6) return { text: `Keep ${set.weight} kg`, tone: "same" };
    return { text: `${set.weight} kg · beat ${set.reps} reps`, tone: "same" };
  }

  function addSet(
    workoutExerciseId: string
  ) {
    setActiveWorkout((current) => {
      if (!current) {
        return current;
      }

      return {
        ...current,
        exercises: current.exercises.map(
          (exercise) => {
            if (
              exercise.id !== workoutExerciseId
            ) {
              return exercise;
            }

            const previous =
              exercise.sets[
                exercise.sets.length - 1
              ];

            const newSet: WorkoutSet = {
              id: makeId(),
              weight: previous?.weight ?? 0,
              reps: previous?.reps ?? 0,
              rir: previous?.rir ?? null,
              completed: false,
            };

            return {
              ...exercise,
              sets: [...exercise.sets, newSet],
            };
          }
        ),
      };
    });
  }

  function moveExercise(workoutExerciseId: string, direction: -1 | 1) {
    setActiveWorkout((current) => {
      if (!current) return current;
      const exercises = [...current.exercises];
      const index = exercises.findIndex((item) => item.id === workoutExerciseId);
      const target = index + direction;
      if (index < 0 || target < 0 || target >= exercises.length) return current;
      [exercises[index], exercises[target]] = [exercises[target], exercises[index]];
      return { ...current, exercises };
    });
  }

  function updateSet(
    workoutExerciseId: string,
    setId: string,
    field: "weight" | "reps" | "rir",
    value: string
  ) {
    setActiveWorkout((current) => {
      if (!current) {
        return current;
      }

      return {
        ...current,
        exercises: current.exercises.map(
          (exercise) =>
            exercise.id === workoutExerciseId
              ? {
                  ...exercise,
                  sets: exercise.sets.map(
                    (set) =>
                      set.id === setId
                        ? {
                            ...set,
                            [field]:
                              field === "rir"
                                ? value === ""
                                  ? null
                                  : Number(value)
                                : value === ""
                                  ? 0
                                  : field === "weight" && unit === "lb"
                                    ? lbToKg(Number(value))
                                    : Number(value),
                          }
                        : set
                  ),
                }
              : exercise
        ),
      };
    });
  }

  function toggleSet(
    workoutExerciseId: string,
    setId: string
  ) {
    setActiveWorkout((current) => {
      if (!current) {
        return current;
      }

      return {
        ...current,
        exercises: current.exercises.map(
          (exercise) =>
            exercise.id === workoutExerciseId
              ? {
                  ...exercise,
                  sets: exercise.sets.map(
                    (set) => {
                      if (set.id !== setId) {
                        return set;
                      }

                      return {
                        ...set,
                        completed:
                          !set.completed,
                      };
                    }
                  ),
                }
              : exercise
        ),
      };
    });
    const targetExercise = activeWorkout?.exercises.find((e) => e.id === workoutExerciseId);
    const targetSet = targetExercise?.sets.find((set) => set.id === setId);
    if (restTimerEnabled && targetSet && !targetSet.completed) {
      setRestSecondsLeft(restDuration);
      setToast(`Rest timer started · ${Math.floor(restDuration / 60)}:${String(restDuration % 60).padStart(2, "0")}`);
    }
  }

  function deleteSet(
    workoutExerciseId: string,
    setId: string
  ) {
    setActiveWorkout((current) => {
      if (!current) {
        return current;
      }

      return {
        ...current,
        exercises: current.exercises.map(
          (exercise) =>
            exercise.id === workoutExerciseId
              ? {
                  ...exercise,
                  sets: exercise.sets.filter(
                    (set) => set.id !== setId
                  ),
                }
              : exercise
        ),
      };
    });
  }

  return (
    <div className="mt-8">
      <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl shadow-black/10">
        <div className="flex flex-wrap items-start justify-between gap-5">
          <div className="flex-1">
            <p className="text-sm font-semibold tracking-widest text-green-400">
              ACTIVE WORKOUT
            </p>

            <input
              value={activeWorkout.name}
              onChange={(event) =>
                changeWorkoutName(
                  event.target.value
                )
              }
              className="mt-2 w-full max-w-xl bg-transparent text-4xl font-black tracking-tight outline-none"
              placeholder="Workout name"
            />

            <p className="mt-2 text-sm text-slate-400">
              Started{" "}
              {formatTime(
                activeWorkout.startedAt
              )}
            </p>

            <div className="mt-4 inline-flex items-center gap-3 rounded-2xl border border-green-400/20 bg-green-400/10 px-4 py-3">
              <span className="text-sm font-semibold text-green-400">
                WORKOUT TIME
              </span>

              <span className="font-mono text-xl font-bold text-white">
                {formatLiveDuration(
                  elapsedSeconds
                )}
              </span>
            </div>

            <div className="mt-5 grid grid-cols-3 gap-2 sm:max-w-xl">
              <LiveMetric label="Duration" value={formatLiveDuration(elapsedSeconds)} />
              <LiveMetric
                label="Volume"
                value={`${Math.round((unit === "lb" ? 2.2046226218 : 1) * activeWorkout.exercises.reduce((total, item) => total + item.sets.filter(s => s.completed).reduce((sum, set) => sum + set.weight * set.reps, 0), 0)).toLocaleString()} ${weightLabel}`}
              />
              <LiveMetric
                label="Sets"
                value={`${activeWorkout.exercises.reduce((total, item) => total + item.sets.filter(s => s.completed).length, 0)}/${activeWorkout.exercises.reduce((total, item) => total + item.sets.length, 0)}`}
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button onClick={togglePause} className={`rounded-xl border px-4 py-3 text-sm font-bold ${paused ? "border-amber-300 bg-amber-50 text-amber-700" : "border-slate-300 text-slate-700"}`}>
              {paused ? "Resume" : "Pause"}
            </button>
            <button onClick={() => setUnit(unit === "kg" ? "lb" : "kg")} className="rounded-xl border border-slate-300 px-4 py-3 text-sm font-bold">
              {unit.toUpperCase()}
            </button>
            <button
              onClick={saveCurrentWorkout}
              className="rounded-xl border border-slate-300 px-4 py-3 text-sm font-semibold transition hover:bg-slate-50"
            >
              Save as template
            </button>

            <button
              onClick={discardWorkout}
              className="rounded-xl border border-red-900 px-4 py-3 text-sm font-semibold text-red-400 transition hover:bg-red-950/30"
            >
              Discard
            </button>
          </div>
        </div>
      </section>

      <div className="mt-6 grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
        <div className="space-y-5">
        {activeWorkout.exercises.map(
          (exercise) => {
            const previous = findPreviousExercise(
              history,
              exercise.exerciseId,
              displayUnits
            );

            return (
              <section
                key={exercise.id}
                className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-xl shadow-black/10"
              >
                <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 p-6">
                  <div className="flex min-w-0 gap-4">
                    <div className="shrink-0">
                      <ExerciseMedia
                        name={exercise.exerciseName}
                        compact
                      />
                    </div>

                    <div className="min-w-0">
                    <h3 className="text-xl font-semibold">
                      {exercise.exerciseName}
                    </h3>
                    {supersetGroups[exercise.id] && (
                      <span className="mt-2 inline-flex rounded-full bg-violet-100 px-2.5 py-1 text-[10px] font-black uppercase tracking-wider text-violet-700">
                        Superset
                      </span>
                    )}

                    <button
                      onClick={() =>
                        setOpenDetailsByExercise(
                          (current) => ({
                            ...current,
                            [exercise.id]:
                              !current[exercise.id],
                          })
                        )
                      }
                      className="mt-1 text-xs font-semibold text-green-400 hover:text-green-300"
                    >
                      {openDetailsByExercise[
                        exercise.id
                      ]
                        ? "Hide exercise guide"
                        : "Exercise guide"}
                    </button>

                    <p className="mt-2 text-sm text-slate-400">
                      {previous
                        ? `Previous: ${previous}`
                        : "No previous performance"}
                    </p>

                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button onClick={() => toggleCollapse(exercise.id)} className="rounded-lg border border-slate-200 px-2 py-1 text-xs font-bold text-slate-500">{collapsedExercises[exercise.id] ? "Open" : "Collapse"}</button>
                    <button onClick={() => toggleSuperset(exercise.id)} className={`rounded-lg border px-2 py-1 text-xs font-bold ${supersetGroups[exercise.id] ? "border-violet-300 bg-violet-50 text-violet-700" : "border-slate-200 text-slate-500"}`}>Superset</button>
                    <button onClick={() => moveExercise(exercise.id, -1)} className="rounded-lg border border-slate-200 px-2 py-1 text-xs font-bold text-slate-500">↑</button>
                    <button onClick={() => moveExercise(exercise.id, 1)} className="rounded-lg border border-slate-200 px-2 py-1 text-xs font-bold text-slate-500">↓</button>
                    <button onClick={() => setReplaceExerciseId(exercise.id)} className="rounded-lg border border-slate-200 px-2 py-1 text-xs font-bold text-slate-500">Replace</button>
                    <button
                      onClick={() => removeExercise(exercise.id)}
                      className="text-sm text-red-500"
                    >
                      Remove
                    </button>
                  </div>
                </div>

                {!collapsedExercises[exercise.id] && <>
                {openDetailsByExercise[
                  exercise.id
                ] && (
                  <div className="border-b border-slate-200 bg-white/50 p-5">
                    <div className="grid gap-5 lg:grid-cols-[minmax(280px,0.9fr)_1.1fr]">
                      <ExerciseMedia
                        name={exercise.exerciseName}
                      />

                      <div>
                        <p className="text-xs font-semibold uppercase tracking-widest text-green-400">
                          Instructions
                        </p>
                        <p className="mt-2 text-sm leading-6 text-slate-600">
                          {exerciseInstructions(
                            exercise.exerciseName
                          )}
                        </p>

                        <p className="mt-4 text-xs text-slate-400">
                          Visual animation slot ready — real exercise GIFs/images can be connected here without changing the workout logger.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                <div className="p-4 sm:p-6">
                  <div className="mb-5 grid gap-4 lg:grid-cols-[minmax(260px,0.85fr)_1.15fr]">
                    <div>
                      <ExerciseMedia
                        name={exercise.exerciseName}
                      />

                      <div className="mt-2 flex items-center gap-2">
                        <button
                          onClick={() =>
                            setOpenDetailsByExercise(
                              (current) => ({
                                ...current,
                                [exercise.id]: true,
                              })
                            )
                          }
                          className="flex-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-600 transition hover:border-green-400"
                        >
                          Instructions
                        </button>

                        <div className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-400">
                          {exerciseBadge(
                            exercise.exerciseName
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="rounded-2xl border border-slate-200 bg-white/60 p-4">
                      <p className="text-xs font-semibold uppercase tracking-widest text-slate-400">
                        Current exercise
                      </p>
                      <p className="mt-2 text-lg font-bold">
                        {exercise.exerciseName}
                      </p>
                      <p className="mt-2 text-sm leading-6 text-slate-500">
                        {exerciseInstructions(
                          exercise.exerciseName
                        )}
                      </p>
                    </div>
                    <ExerciseProgressMini
                      history={history}
                      exerciseId={exercise.exerciseId}
                      displayUnits={displayUnits}
                    />
                  </div>
                  <div
                    className={`grid gap-2 px-2 text-center text-xs font-semibold uppercase tracking-wide text-slate-400 ${
                      showRirByExercise[exercise.id]
                        ? "grid-cols-[40px_1.2fr_1fr_1fr_1fr_52px_36px]"
                        : "grid-cols-[40px_1.2fr_1fr_1fr_52px_36px]"
                    }`}
                  >
                    <span>Set</span>
                    <span>Previous</span>
                    <span>{weightLabel}</span>
                    <span>Reps</span>
                    {showRirByExercise[exercise.id] && (
                      <span>RIR</span>
                    )}
                    <span>Done</span>
                    <span />
                  </div>

                  <div className="mt-2 space-y-2">
                    {exercise.sets.map(
                      (set, index) => (
                        <div
                          key={set.id}
                          className={`grid items-center gap-2 rounded-xl p-2 ${
                            showRirByExercise[exercise.id]
                              ? "grid-cols-[40px_1.2fr_1fr_1fr_1fr_52px_36px]"
                              : "grid-cols-[40px_1.2fr_1fr_1fr_52px_36px]"
                          } ${
                            set.completed
                              ? "border border-green-400/30 bg-green-400/10"
                              : "border border-transparent bg-white"
                          }`}
                        >
                          <button
                            onClick={() => cycleSetType(set.id)}
                            title="Set type: Normal → Warm-up → Drop → Failure"
                            className={`mx-auto flex h-8 w-8 items-center justify-center rounded-lg text-xs font-black ${
                              (setTypes[set.id] ?? "N") === "W"
                                ? "bg-amber-100 text-amber-700"
                                : (setTypes[set.id] ?? "N") === "D"
                                  ? "bg-violet-100 text-violet-700"
                                  : (setTypes[set.id] ?? "N") === "F"
                                    ? "bg-red-100 text-red-700"
                                    : "bg-slate-100 text-slate-600"
                            }`}
                          >
                            {(setTypes[set.id] ?? "N") === "N" ? index + 1 : setTypes[set.id]}
                          </button>

                          <div className="text-center">
                            <p className="text-xs text-slate-400">{getPreviousSetText(history, exercise.exerciseId, index, displayUnits)}</p>
                            {progressiveSuggestion(exercise.exerciseId, index) && (
                              <p className="mt-1 text-[10px] font-bold text-emerald-600">{progressiveSuggestion(exercise.exerciseId, index)?.text}</p>
                            )}
                          </div>

                          <div className="min-w-0">
                            <input
                              type="number"
                              step={unit === "lb" ? "1" : "0.5"}
                              min="0"
                              value={
                                set.weight === 0
                                  ? ""
                                  : displayWeight(set.weight)
                              }
                              onChange={(event) =>
                                updateSet(
                                  exercise.id,
                                  set.id,
                                  "weight",
                                  event.target.value
                                )
                              }
                              placeholder={weightLabel}
                              className="w-full min-w-0 rounded-lg border border-slate-200 bg-white p-3 text-center outline-none focus:border-green-400"
                            />
                            <div className="mt-1 flex justify-center gap-1">
                              <button type="button" onClick={() => quickWeight(exercise.id, set.id, unit === "lb" ? lbToKg(-5) : -2.5)} className="rounded-lg bg-slate-100 px-2 py-1 text-[10px] font-bold text-slate-600">{unit === "lb" ? "−5" : "−2.5"}</button>
                              <button type="button" onClick={() => quickWeight(exercise.id, set.id, unit === "lb" ? lbToKg(5) : 2.5)} className="rounded-lg bg-slate-100 px-2 py-1 text-[10px] font-bold text-slate-600">{unit === "lb" ? "+5" : "+2.5"}</button>
                            </div>
                          </div>

                          <input
                            type="number"
                            min="0"
                            value={
                              set.reps === 0
                                ? ""
                                : set.reps
                            }
                            onChange={(event) =>
                              updateSet(
                                exercise.id,
                                set.id,
                                "reps",
                                event.target.value
                              )
                            }
                            placeholder="reps"
                            className="min-w-0 rounded-lg border border-slate-200 bg-white p-3 text-center outline-none focus:border-green-400"
                          />

                          {showRirByExercise[exercise.id] && (
                            <input
                              type="number"
                              min="0"
                              max="10"
                              value={
                                set.rir === null
                                  ? ""
                                  : set.rir
                              }
                              onChange={(event) =>
                                updateSet(
                                  exercise.id,
                                  set.id,
                                  "rir",
                                  event.target.value
                                )
                              }
                              placeholder="RIR"
                              className="min-w-0 rounded-lg border border-slate-200 bg-white p-3 text-center outline-none focus:border-green-400"
                            />
                          )}

                          <button
                            onClick={() =>
                              toggleSet(
                                exercise.id,
                                set.id
                              )
                            }
                            title={
                              set.completed &&
                              isPersonalRecord(
                                history,
                                exercise.exerciseId,
                                set
                              )
                                ? "Personal Record"
                                : "Mark set done"
                            }
                            className={`mx-auto flex h-9 min-w-9 items-center justify-center rounded-lg border px-1 text-xs font-bold ${
                              set.completed
                                ? "border-green-400 bg-green-400 text-black"
                                : "border-slate-300 text-slate-400"
                            }`}
                          >
                            {set.completed &&
                            isPersonalRecord(
                              history,
                              exercise.exerciseId,
                              set
                            )
                              ? "PR"
                              : "✓"}
                          </button>

                          <button
                            onClick={() =>
                              deleteSet(
                                exercise.id,
                                set.id
                              )
                            }
                            className="text-zinc-600 transition hover:text-red-400"
                          >
                            ×
                          </button>
                        </div>
                      )
                    )}
                  </div>

                  <details className="mt-4 rounded-xl border border-slate-200 bg-white">
                    <summary className="cursor-pointer px-4 py-3 text-sm text-slate-400">
                      + Exercise note
                    </summary>

                    <div className="border-t border-slate-200 p-3">
                      <input
                        value={
                          exerciseNotes[
                            exercise.exerciseId
                          ] ?? ""
                        }
                        onChange={(event) =>
                          saveExerciseNote(
                            exercise.exerciseId,
                            event.target.value
                          )
                        }
                        placeholder="e.g. seat 4, wider grip"
                        className="w-full rounded-lg border border-slate-200 bg-white px-3 py-3 text-sm outline-none focus:border-green-400"
                      />
                    </div>
                  </details>

                  <div className="mt-4 flex gap-2">
                    <button
                      onClick={() =>
                        addSet(exercise.id)
                      }
                      className="flex-1 rounded-xl border border-slate-300 py-3 text-sm font-semibold transition hover:bg-slate-50"
                    >
                      + Add set
                    </button>

                    <button
                      onClick={() =>
                        setShowRirByExercise(
                          (current) => ({
                            ...current,
                            [exercise.id]:
                              !current[exercise.id],
                          })
                        )
                      }
                      className="rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-400 transition hover:text-white"
                    >
                      {showRirByExercise[exercise.id]
                        ? "Hide RIR"
                        : "+ RIR"}
                    </button>
                  </div>
                </div>
                </>}
              </section>
            );
          }
        )}
        </div>

        <aside className="h-fit rounded-3xl border border-slate-200 bg-white p-5 xl:sticky xl:top-6">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-green-400">
                Exercise Library
              </p>
              <h3 className="mt-1 text-xl font-bold">
                Add exercise
              </h3>
            </div>

            <span className="rounded-full bg-white px-3 py-1 text-xs text-slate-400">
              {filteredExercises.length}
            </span>
          </div>

          <input
            value={search}
            onChange={(event) =>
              setSearch(event.target.value)
            }
            placeholder="Search exercises..."
            className="mt-4 w-full rounded-xl border border-slate-300 bg-white p-3 text-sm outline-none focus:border-green-400"
          />

          <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
            <FilterButton
              name="All"
              active={muscleFilter === "All"}
              onClick={() =>
                setMuscleFilter("All")
              }
            />

            {muscleGroups.map((group) => (
              <FilterButton
                key={group}
                name={group}
                active={
                  muscleFilter === group
                }
                onClick={() =>
                  setMuscleFilter(group)
                }
              />
            ))}
          </div>

          <div className="mt-4 max-h-[560px] space-y-2 overflow-y-auto pr-1">
            {filteredExercises.map(
              (libraryExercise) => (
                <button
                  key={libraryExercise.id}
                  onClick={() =>
                    addExercise(
                      libraryExercise
                    )
                  }
                  className="flex w-full items-center gap-3 rounded-xl border border-slate-200 bg-white p-3 text-left transition hover:border-green-400/60"
                >
                  <div className="shrink-0">
                    <ExerciseMedia
                      name={libraryExercise.name}
                      compact
                    />
                  </div>

                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">
                      {libraryExercise.name}
                    </p>
                    <p className="mt-0.5 text-xs text-slate-400">
                      {
                        libraryExercise.muscleGroup
                      }
                    </p>
                  </div>

                  <span className="text-lg text-green-400">
                    +
                  </span>
                </button>
              )
            )}
          </div>
        </aside>
      </div>

      <button
        onClick={() =>
          setShowExercisePicker(true)
        }
        className="mt-6 w-full rounded-2xl border border-dashed border-slate-300 p-4 font-semibold text-slate-500 transition hover:border-green-400 hover:bg-white hover:text-white xl:hidden"
      >
        + Add exercise
      </button>

      {showExercisePicker && (
        <section className="mt-5 rounded-3xl border border-green-400/30 bg-white p-6">
          <div className="flex items-center justify-between gap-4">
            <h2 className="text-2xl font-semibold">
              Add exercise
            </h2>

            <button
              onClick={() =>
                setShowExercisePicker(false)
              }
              className="text-slate-500"
            >
              Close
            </button>
          </div>

          <input
            value={search}
            onChange={(event) =>
              setSearch(event.target.value)
            }
            placeholder="Search exercises..."
            className="mt-5 w-full rounded-xl border border-slate-300 bg-white p-4 outline-none focus:border-green-400"
          />

          <div className="mt-4 flex flex-wrap gap-2">
            <FilterButton
              name="All"
              active={
                muscleFilter === "All"
              }
              onClick={() =>
                setMuscleFilter("All")
              }
            />

            {muscleGroups.map((group) => (
              <FilterButton
                key={group}
                name={group}
                active={
                  muscleFilter === group
                }
                onClick={() =>
                  setMuscleFilter(group)
                }
              />
            ))}
          </div>

          <div className="mt-5 max-h-96 space-y-2 overflow-y-auto">
            {filteredExercises.map(
              (exercise) => (
                <button
                  key={exercise.id}
                  onClick={() =>
                    addExercise(exercise)
                  }
                  className="flex w-full items-center justify-between rounded-xl border border-slate-200 bg-white p-4 text-left transition hover:border-green-400/60"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200 bg-white text-[11px] font-black tracking-wider text-green-400">
                      {exerciseBadge(exercise.name)}
                    </div>
                    <div>
                    <p className="font-semibold">
                      {exercise.name}
                    </p>

                    <p className="mt-1 text-xs text-slate-400">
                      {exercise.muscleGroup}
                    </p>
                    </div>
                  </div>

                  <span className="text-green-400">
                    Add
                  </span>
                </button>
              )
            )}
          </div>
        </section>
      )}

      <details className="mt-8 rounded-2xl border border-slate-200 bg-white">
        <summary className="cursor-pointer px-5 py-4 text-sm font-semibold text-slate-500">
          + Add workout note
        </summary>

        <div className="border-t border-slate-200 p-5">
          <textarea
            value={workoutNote}
            onChange={(event) =>
              saveWorkoutNote(event.target.value)
            }
            placeholder="Optional note about this workout..."
            rows={3}
            className="w-full resize-none rounded-xl border border-slate-300 bg-white p-4 outline-none focus:border-green-400"
          />
        </div>
      </details>

      <button
        onClick={() => setShowFinishReview(true)}
        className="mt-4 w-full rounded-2xl bg-emerald-500 p-5 text-lg font-black text-white transition hover:bg-emerald-600"
      >
        Review & Finish
      </button>

      {restSecondsLeft > 0 && (
        <div className="fixed bottom-24 left-1/2 z-[70] w-[min(92vw,430px)] -translate-x-1/2 rounded-3xl border border-emerald-200 bg-white p-4 shadow-2xl">
          <div className="flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500 font-mono text-lg font-black text-white">
              {Math.floor(restSecondsLeft / 60)}:{String(restSecondsLeft % 60).padStart(2, "0")}
            </div>
            <div className="min-w-0 flex-1"><p className="font-black">Rest timer</p><p className="text-xs text-slate-400">Next set when you are ready.</p></div>
            <button onClick={() => setRestSecondsLeft((v) => v + 30)} className="rounded-xl bg-slate-100 px-3 py-2 text-xs font-black">+30</button>
            <button onClick={() => setRestSecondsLeft(0)} className="rounded-xl bg-slate-950 px-3 py-2 text-xs font-black text-white">Skip</button>
          </div>
        </div>
      )}

      <div className="sticky bottom-3 z-40 mt-4 flex gap-2 rounded-2xl border border-slate-200 bg-white/95 p-2 shadow-xl backdrop-blur xl:hidden">
        <button onClick={() => setShowExercisePicker(true)} className="flex-1 rounded-xl bg-slate-100 py-3 text-sm font-black">+ Exercise</button>
        <button onClick={() => setShowFinishReview(true)} className="flex-1 rounded-xl bg-emerald-500 py-3 text-sm font-black text-white">Finish</button>
      </div>

      {toast && <div className="fixed right-4 top-4 z-[100] rounded-2xl bg-slate-950 px-4 py-3 text-sm font-bold text-white shadow-xl">{toast}</div>}
      {replaceExerciseId && (
        <div className="fixed inset-0 z-[90] flex items-end justify-center bg-slate-950/40 p-3 sm:items-center">
          <div className="max-h-[85vh] w-full max-w-xl overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between">
              <div><p className="text-xs font-bold uppercase tracking-widest text-emerald-600">Replace exercise</p><h3 className="mt-1 text-2xl font-black">Choose replacement</h3></div>
              <button onClick={() => setReplaceExerciseId(null)} className="h-10 w-10 rounded-xl bg-slate-100 font-black">×</button>
            </div>
            <input value={replaceSearch} onChange={e=>setReplaceSearch(e.target.value)} placeholder="Search exercises..." className="mt-5 w-full rounded-xl border border-slate-200 p-3 outline-none focus:border-emerald-400"/>
            <div className="mt-4 space-y-2">
              {exercises.filter(e=>e.name.toLowerCase().includes(replaceSearch.toLowerCase())).slice(0,30).map(e=>(
                <button key={e.id} onClick={()=>replaceExercise(replaceExerciseId,e)} className="flex w-full items-center gap-3 rounded-2xl border border-slate-200 p-3 text-left hover:border-emerald-400">
                  <ExerciseMedia name={e.name} compact />
                  <div><p className="font-bold">{e.name}</p><p className="text-xs text-slate-400">{e.muscleGroup}</p></div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {showFinishReview && (
        <div className="fixed inset-0 z-[95] flex items-end justify-center bg-slate-950/50 p-3 sm:items-center">
          <div className="w-full max-w-2xl rounded-3xl bg-white p-6 shadow-2xl">
            <div className="flex items-start justify-between gap-4">
              <div><p className="text-xs font-bold uppercase tracking-widest text-emerald-600">Workout review</p><h2 className="mt-1 text-3xl font-black">{activeWorkout.name}</h2></div>
              <button onClick={()=>setShowFinishReview(false)} className="h-10 w-10 rounded-xl bg-slate-100 font-black">×</button>
            </div>
            <div className="mt-6 grid grid-cols-3 gap-3">
              <SummaryMetric label="Duration" value={formatLiveDuration(elapsedSeconds)} />
              <SummaryMetric label="Volume" value={`${Math.round(activeWorkout.exercises.reduce((total, item) => total + item.sets.filter(s=>s.completed).reduce((sum,set)=>sum+set.weight*set.reps,0),0)).toLocaleString()} kg`} />
              <SummaryMetric label="Sets" value={activeWorkout.exercises.reduce((total,item)=>total+item.sets.filter(s=>s.completed).length,0)} />
            </div>
            <div className="mt-6"><p className="text-sm font-black">How did it feel?</p><div className="mt-3 grid grid-cols-5 gap-2">{[1,2,3,4,5].map(n=><button key={n} onClick={()=>setSessionFeeling(n)} className={`rounded-xl py-3 font-black ${sessionFeeling===n?"bg-emerald-500 text-white":"bg-slate-100 text-slate-500"}`}>{n}</button>)}</div></div>
            <div className="mt-6 rounded-2xl bg-slate-50 p-4"><p className="text-xs font-bold uppercase tracking-widest text-slate-400">Mucipes summary</p><p className="mt-2 text-sm leading-6 text-slate-600">{activeWorkout.exercises.reduce((t,e)=>t+e.sets.filter(s=>s.completed).length,0)} completed sets across {activeWorkout.exercises.length} exercises.{activeWorkout.exercises.some(e=>e.sets.some(set=>set.completed && isPersonalRecord(history,e.exerciseId,set))) ? " New personal record detected." : ""}</p></div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <SummaryMetric label="PRs" value={activeWorkout.exercises.reduce((total,e)=>total+e.sets.filter(set=>set.completed && isPersonalRecord(history,e.exerciseId,set)).length,0)} />
              <SummaryMetric label="Exercises" value={activeWorkout.exercises.length} />
            </div>
            <button onClick={()=>{ localStorage.setItem(`bodypilot-workout-feeling-${activeWorkout.id}`,String(sessionFeeling)); setShowFinishReview(false); finishWorkout(); }} className="mt-6 w-full rounded-2xl bg-emerald-500 py-4 text-lg font-black text-white">Save Workout</button>
          </div>
        </div>
      )}

    </div>
  );
}

function SavedWorkoutsTab({
  savedWorkouts, setSavedWorkouts, exercises, activeWorkout, startSavedWorkout, deleteSavedWorkout, setActiveTab,
}: {
  savedWorkouts: SavedWorkout[];
  setSavedWorkouts: React.Dispatch<React.SetStateAction<SavedWorkout[]>>;
  exercises: Exercise[];
  activeWorkout: ActiveWorkout | null;
  startSavedWorkout: (workout: SavedWorkout) => void;
  deleteSavedWorkout: (id: string) => void;
  setActiveTab: (tab: TrainingTab) => void;
}) {
  const [builderOpen,setBuilderOpen]=useState(false);
  const [routineName,setRoutineName]=useState("");
  const [routineSearch,setRoutineSearch]=useState("");
  const [builderExercises,setBuilderExercises]=useState<Array<{exercise:Exercise;sets:number;minReps:number;maxReps:number;rir:number;rest:number}>>([]);

  function addBuilderExercise(exercise:Exercise){if(builderExercises.some(x=>x.exercise.id===exercise.id))return;setBuilderExercises(c=>[...c,{exercise,sets:3,minReps:8,maxReps:12,rir:2,rest:120}]);}
  function saveRoutine(){
    if(!routineName.trim()||!builderExercises.length)return;
    const id=makeId();
    const routine:SavedWorkout={id,name:routineName.trim(),createdAt:new Date().toISOString(),exercises:builderExercises.map(x=>({exerciseId:x.exercise.id,exerciseName:x.exercise.name,defaultSets:x.sets}))};
    try{const raw=localStorage.getItem(ROUTINE_TARGETS_KEY);const all=raw?JSON.parse(raw):{};all[id]=builderExercises.reduce((acc,x)=>({...acc,[x.exercise.id]:{min:x.minReps,max:x.maxReps,rir:x.rir,rest:x.rest}}),{});localStorage.setItem(ROUTINE_TARGETS_KEY,JSON.stringify(all));}catch{}
    setSavedWorkouts(c=>[...c,routine]);setRoutineName("");setBuilderExercises([]);setBuilderOpen(false);
  }
  function starter(name:string,names:string[]){const picked=names.map(n=>exercises.find(e=>e.name.toLowerCase().includes(n))).filter(Boolean) as Exercise[];setRoutineName(name);setBuilderExercises(picked.map(exercise=>({exercise,sets:3,minReps:8,maxReps:12,rir:2,rest:120})));setBuilderOpen(true);}

  return <section className="mt-8">
    <div className="flex flex-wrap items-end justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-widest text-emerald-600">Routines</p><h2 className="mt-1 text-3xl font-black">Routine Builder</h2><p className="mt-2 text-slate-500">Build Push, Pull, Legs or custom sessions with target sets and reps.</p></div><button onClick={()=>setBuilderOpen(true)} className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-black text-white">+ Create Routine</button></div>
    <div className="mt-5 flex flex-wrap gap-2"><button onClick={()=>starter("Push",["bench press","shoulder press","lateral raise","triceps"])} className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold">Push starter</button><button onClick={()=>starter("Pull",["lat pulldown","row","curl"])} className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold">Pull starter</button><button onClick={()=>starter("Legs",["squat","rdl","leg extension","leg curl","calf"])} className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold">Legs starter</button></div>
    <div className="mt-6 grid gap-5 md:grid-cols-2">{savedWorkouts.map(workout=><div key={workout.id} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm"><div className="flex justify-between gap-4"><div><h3 className="text-xl font-black">{workout.name}</h3><p className="mt-1 text-sm text-slate-400">{workout.exercises.length} exercises</p></div><button onClick={()=>deleteSavedWorkout(workout.id)} className="text-sm font-bold text-red-500">Delete</button></div><div className="mt-5 space-y-2">{workout.exercises.map(ex=><div key={ex.exerciseId} className="flex justify-between rounded-xl bg-slate-50 px-4 py-3"><span className="font-semibold">{ex.exerciseName}</span><span className="text-sm text-slate-400">{ex.defaultSets} sets</span></div>)}</div><button disabled={Boolean(activeWorkout)} onClick={()=>startSavedWorkout(workout)} className="mt-5 w-full rounded-xl bg-emerald-500 py-3 font-black text-white disabled:bg-slate-200 disabled:text-slate-400">{activeWorkout?"Finish current workout first":"Start workout"}</button></div>)}</div>
    {!savedWorkouts.length&&<div className="mt-6 rounded-3xl border border-dashed border-slate-300 bg-white p-8 text-center text-slate-500">No routines yet. Create one or start with Push / Pull / Legs.</div>}
    {builderOpen&&<div className="fixed inset-0 z-[90] flex items-end justify-center bg-slate-950/45 p-3 sm:items-center"><div className="max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl">
      <div className="flex items-start justify-between"><div><p className="text-xs font-bold uppercase tracking-widest text-emerald-600">Routine Builder</p><h3 className="mt-1 text-3xl font-black">Build your routine</h3></div><button onClick={()=>setBuilderOpen(false)} className="h-10 w-10 rounded-xl bg-slate-100 font-black">×</button></div>
      <input value={routineName} onChange={e=>setRoutineName(e.target.value)} placeholder="Routine name — e.g. Push A" className="mt-5 w-full rounded-2xl border border-slate-200 p-4 text-lg font-bold outline-none focus:border-emerald-400"/>
      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_.85fr]"><div><p className="text-sm font-black">Exercises</p><div className="mt-3 space-y-3">{builderExercises.map(item=><div key={item.exercise.id} className="rounded-2xl border border-slate-200 p-4"><div className="flex items-center justify-between gap-3"><div className="flex items-center gap-3"><ExerciseMedia name={item.exercise.name} compact/><p className="font-black">{item.exercise.name}</p></div><button onClick={()=>setBuilderExercises(c=>c.filter(x=>x.exercise.id!==item.exercise.id))} className="text-red-500">×</button></div><div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-5"><BuilderNumber label="Sets" value={item.sets} onChange={v=>setBuilderExercises(c=>c.map(x=>x.exercise.id===item.exercise.id?{...x,sets:Math.max(1,v)}:x))}/><BuilderNumber label="Min reps" value={item.minReps} onChange={v=>setBuilderExercises(c=>c.map(x=>x.exercise.id===item.exercise.id?{...x,minReps:Math.max(1,v)}:x))}/><BuilderNumber label="Max reps" value={item.maxReps} onChange={v=>setBuilderExercises(c=>c.map(x=>x.exercise.id===item.exercise.id?{...x,maxReps:Math.max(1,v)}:x))}/><BuilderNumber label="RIR" value={item.rir} onChange={v=>setBuilderExercises(c=>c.map(x=>x.exercise.id===item.exercise.id?{...x,rir:Math.max(0,v)}:x))}/><BuilderNumber label="Rest sec" value={item.rest} onChange={v=>setBuilderExercises(c=>c.map(x=>x.exercise.id===item.exercise.id?{...x,rest:Math.max(30,v)}:x))}/></div></div>)}{!builderExercises.length&&<div className="rounded-2xl bg-slate-50 p-5 text-sm text-slate-400">Add exercises from the library →</div>}</div></div>
      <div className="rounded-2xl bg-slate-50 p-4"><input value={routineSearch} onChange={e=>setRoutineSearch(e.target.value)} placeholder="Search exercise..." className="w-full rounded-xl border border-slate-200 bg-white p-3 outline-none"/><div className="mt-3 max-h-[420px] space-y-2 overflow-y-auto">{exercises.filter(e=>e.name.toLowerCase().includes(routineSearch.toLowerCase())).slice(0,40).map(e=><button key={e.id} onClick={()=>addBuilderExercise(e)} className="flex w-full items-center gap-3 rounded-xl bg-white p-3 text-left hover:ring-1 hover:ring-emerald-400"><ExerciseMedia name={e.name} compact/><div><p className="text-sm font-bold">{e.name}</p><p className="text-xs text-slate-400">{e.muscleGroup}</p></div><span className="ml-auto text-emerald-500">+</span></button>)}</div></div></div>
      <button disabled={!routineName.trim()||!builderExercises.length} onClick={saveRoutine} className="mt-6 w-full rounded-2xl bg-emerald-500 py-4 font-black text-white disabled:bg-slate-200 disabled:text-slate-400">Save Routine</button>
    </div></div>}
  </section>;
}


function HistoryTab({
  history,
  deleteHistoryEntry,
  displayUnits,
}: {
  history: WorkoutHistoryEntry[];
  deleteHistoryEntry: (
    id: string
  ) => void;
  displayUnits: "metric" | "imperial";
}) {
  const [openWorkoutId, setOpenWorkoutId] =
    useState<string | null>(null);

  return (
    <section className="mt-8">
      <h2 className="text-3xl font-bold">
        Workout History
      </h2>

      <p className="mt-2 text-slate-500">
        Every finished workout and every set
        you logged.
      </p>

      {history.length === 0 ? (
        <div className="mt-6 rounded-3xl border border-slate-200 bg-white p-8 text-slate-400">
          Finish your first workout and it will
          appear here.
        </div>
      ) : (
        <div className="mt-6 space-y-4">
          {history.map((workout) => {
            const isOpen =
              openWorkoutId === workout.id;

            const totalSets =
              workout.exercises.reduce(
                (total, exercise) =>
                  total +
                  exercise.sets.length,
                0
              );

            return (
              <div
                key={workout.id}
                className="overflow-hidden rounded-3xl border border-slate-200 bg-white"
              >
                <button
                  onClick={() =>
                    setOpenWorkoutId(
                      isOpen
                        ? null
                        : workout.id
                    )
                  }
                  className="flex w-full flex-wrap items-center justify-between gap-5 p-6 text-left"
                >
                  <div>
                    <h3 className="text-xl font-semibold">
                      {workout.name}
                    </h3>

                    <p className="mt-1 text-sm text-slate-400">
                      {formatDate(
                        workout.finishedAt
                      )}
                    </p>
                  </div>

                  <div className="text-right">
                    <p className="font-semibold">
                      {totalSets} sets
                    </p>

                    <p className="text-sm text-slate-400">
                      {formatDuration(
                        workout.durationSeconds
                      )}
                    </p>
                  </div>
                </button>

                {isOpen && (
                  <div className="border-t border-slate-200 p-6">
                    <div className="space-y-5">
                      {workout.exercises.map(
                        (exercise) => (
                          <div
                            key={exercise.id}
                          >
                            <p className="font-semibold">
                              {
                                exercise.exerciseName
                              }
                            </p>

                            <div className="mt-2 space-y-2">
                              {exercise.sets.map(
                                (
                                  set,
                                  index
                                ) => (
                                  <div
                                    key={
                                      set.id
                                    }
                                    className="flex justify-between rounded-xl bg-white px-4 py-3 text-sm"
                                  >
                                    <span className="text-slate-400">
                                      Set{" "}
                                      {index +
                                        1}
                                    </span>

                                    <span>
                                      {formatStoredWeight(set.weight, displayUnits)} ×{" "}
                                      {
                                        set.reps
                                      }
                                      {set.rir !==
                                      null
                                        ? ` • ${set.rir} RIR`
                                        : ""}
                                    </span>
                                  </div>
                                )
                              )}
                            </div>
                          </div>
                        )
                      )}
                    </div>

                    <button
                      onClick={() =>
                        deleteHistoryEntry(
                          workout.id
                        )
                      }
                      className="mt-6 text-sm text-red-400"
                    >
                      Delete workout
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}

function ExercisesTab({
  exercises,
  history,
  displayUnits,
  customExercises,
  addCustomExercise,
  deleteCustomExercise,
}: {
  exercises: Exercise[];
  history: WorkoutHistoryEntry[];
  displayUnits: "metric" | "imperial";
  customExercises: Exercise[];
  addCustomExercise: (
    exercise: Exercise
  ) => void;
  deleteCustomExercise: (
    id: string
  ) => void;
}) {
  const [search, setSearch] = useState("");

  const [muscleFilter, setMuscleFilter] =
    useState<MuscleGroup | "All">("All");

  const [showCreate, setShowCreate] =
    useState(false);
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);
  const [favorites, setFavorites] = useState<string[]>(() => {
    if (typeof window === "undefined") return [];
    try { return JSON.parse(localStorage.getItem(EXERCISE_FAVORITES_KEY) || "[]"); } catch { return []; }
  });
  const [favoritesOnly, setFavoritesOnly] = useState(false);

  const [newName, setNewName] =
    useState("");

  const [newMuscle, setNewMuscle] =
    useState<MuscleGroup>("Chest");

  useEffect(() => {
    localStorage.setItem(EXERCISE_FAVORITES_KEY, JSON.stringify(favorites));
  }, [favorites]);

  const filtered = exercises.filter(
    (exercise) => {
      const matchesSearch =
        exercise.name
          .toLowerCase()
          .includes(search.toLowerCase());

      const matchesMuscle =
        muscleFilter === "All" ||
        exercise.muscleGroup === muscleFilter;

      const matchesFavorite = !favoritesOnly || favorites.includes(exercise.id);
      return matchesSearch && matchesMuscle && matchesFavorite;
    }
  );

  function createExercise() {
    const name = newName.trim();

    if (!name) {
      return;
    }

    const exists = exercises.some(
      (exercise) =>
        exercise.name.toLowerCase() ===
        name.toLowerCase()
    );

    if (exists) {
      window.alert(
        "An exercise with this name already exists."
      );
      return;
    }

    addCustomExercise({
      id: `custom-${makeId()}`,
      name,
      muscleGroup: newMuscle,
      custom: true,
    });

    setNewName("");
    setShowCreate(false);
  }

  return (
    <section className="mt-8">
      <div className="flex flex-wrap items-start justify-between gap-5">
        <div>
          <h2 className="text-3xl font-bold">
            Exercise Library
          </h2>

          <p className="mt-2 text-slate-500">
            Search Mucipes exercises or
            create your own.
          </p>
        </div>

        <button
          onClick={() =>
            setShowCreate(!showCreate)
          }
          className="rounded-xl bg-green-400 px-5 py-3 font-semibold text-black"
        >
          + Create exercise
        </button>
      </div>

      {showCreate && (
        <div className="mt-6 rounded-3xl border border-green-400/30 bg-white p-6">
          <h3 className="text-xl font-semibold">
            New exercise
          </h3>

          <div className="mt-5 grid gap-3 md:grid-cols-[1fr_220px_auto]">
            <input
              value={newName}
              onChange={(event) =>
                setNewName(
                  event.target.value
                )
              }
              placeholder="Exercise name"
              className="rounded-xl border border-slate-300 bg-white p-4 outline-none focus:border-green-400"
            />

            <select
              value={newMuscle}
              onChange={(event) =>
                setNewMuscle(
                  event.target
                    .value as MuscleGroup
                )
              }
              className="rounded-xl border border-slate-300 bg-white p-4 outline-none focus:border-green-400"
            >
              {muscleGroups.map(
                (group) => (
                  <option
                    key={group}
                    value={group}
                  >
                    {group}
                  </option>
                )
              )}
            </select>

            <button
              onClick={createExercise}
              className="rounded-xl bg-green-400 px-6 font-semibold text-black"
            >
              Create
            </button>
          </div>
        </div>
      )}

      <input
        value={search}
        onChange={(event) =>
          setSearch(event.target.value)
        }
        placeholder="Search exercises..."
        className="mt-6 w-full rounded-xl border border-slate-300 bg-white p-4 outline-none focus:border-green-400"
      />

      <div className="mt-4 flex flex-wrap gap-2">
        <FilterButton
          name="All"
          active={muscleFilter === "All"}
          onClick={() =>
            setMuscleFilter("All")
          }
        />

        {muscleGroups.map((group) => (
          <FilterButton
            key={group}
            name={group}
            active={
              muscleFilter === group
            }
            onClick={() =>
              setMuscleFilter(group)
            }
          />
        ))}
      </div>

      <div className="mt-6 grid gap-3 md:grid-cols-2">
        {filtered.map((exercise) => {
          const isCustom =
            customExercises.some(
              (custom) =>
                custom.id === exercise.id
            );

          return (
            <div
              key={exercise.id}
              className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-5"
            >
              <div>
                <p className="font-semibold">
                  {exercise.name}
                </p>

                <p className="mt-1 text-sm text-slate-400">
                  {exercise.muscleGroup}
                  {isCustom
                    ? " • Custom"
                    : ""}
                </p>
              </div>

              {isCustom && (
                <button
                  onClick={() =>
                    deleteCustomExercise(
                      exercise.id
                    )
                  }
                  className="text-sm text-red-400"
                >
                  Delete
                </button>
              )}
            </div>
          );
        })}
      </div>
    
      {selectedExercise && (
        <div className="fixed inset-0 z-[95] flex items-end justify-center bg-slate-950/45 p-3 sm:items-center">
          <div className="max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl">
            <div className="flex items-start justify-between gap-4">
              <div><p className="text-xs font-bold uppercase tracking-widest text-emerald-600">Exercise Detail</p><h2 className="mt-1 text-3xl font-black">{selectedExercise.name}</h2><p className="mt-1 text-sm text-slate-400">{selectedExercise.muscleGroup}</p></div>
              <button onClick={() => setSelectedExercise(null)} className="h-10 w-10 rounded-xl bg-slate-100 font-black">×</button>
            </div>
            <div className="mt-6 grid gap-6 lg:grid-cols-[.8fr_1.2fr]">
              <div><ExerciseMedia name={selectedExercise.name}/><p className="mt-4 text-sm leading-6 text-slate-600">{exerciseInstructions(selectedExercise.name)}</p></div>
              <ExerciseDetailStats history={history} exerciseId={selectedExercise.id} displayUnits={displayUnits} />
            </div>
          </div>
        </div>
      )}
</section>
  );
}

function TabButton({
  name,
  tab,
  activeTab,
  setActiveTab,
}: {
  name: string;
  tab: TrainingTab;
  activeTab: TrainingTab;
  setActiveTab: (
    tab: TrainingTab
  ) => void;
}) {
  const active = activeTab === tab;

  return (
    <button
      onClick={() => setActiveTab(tab)}
      className={`rounded-xl px-4 py-3 text-sm font-semibold transition ${
        active
          ? "bg-green-400 text-black"
          : "text-slate-500 hover:bg-slate-50 hover:text-white"
      }`}
    >
      {name}
    </button>
  );
}

function FilterButton({
  name,
  active,
  onClick,
}: {
  name: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-4 py-2 text-sm transition ${
        active
          ? "border-green-400 bg-green-400 text-black"
          : "border-slate-300 text-slate-500 hover:text-white"
      }`}
    >
      {name}
    </button>
  );
}

function createEmptySet(): WorkoutSet {
  return {
    id: makeId(),
    weight: 0,
    reps: 0,
    rir: null,
    completed: false,
  };
}

function findPreviousExercise(
  history: WorkoutHistoryEntry[],
  exerciseId: string,
  displayUnits: "metric" | "imperial"
) {
  for (const workout of history) {
    const exercise =
      workout.exercises.find(
        (item) =>
          item.exerciseId === exerciseId
      );

    if (exercise) {
      const validSets =
        exercise.sets.filter(
          (set) =>
            set.weight > 0 ||
            set.reps > 0
        );

      if (validSets.length > 0) {
        return validSets
          .map(
            (set) =>
              `${formatStoredWeight(set.weight, displayUnits)} × ${set.reps}`
          )
          .join(" | ");
      }
    }
  }

  return null;
}

function getPreviousSetText(
  history: WorkoutHistoryEntry[],
  exerciseId: string,
  setIndex: number,
  displayUnits: "metric" | "imperial"
) {
  for (const workout of history) {
    const exercise =
      workout.exercises.find(
        (item) =>
          item.exerciseId === exerciseId
      );

    const set = exercise?.sets[setIndex];

    if (
      set &&
      (set.weight > 0 || set.reps > 0)
    ) {
      return `${formatStoredWeight(set.weight, displayUnits)} × ${set.reps}`;
    }
  }

  return "—";
}

function estimatedOneRepMax(
  weight: number,
  reps: number
) {
  if (weight <= 0 || reps <= 0) {
    return 0;
  }

  return weight * (1 + reps / 30);
}

function isPersonalRecord(
  history: WorkoutHistoryEntry[],
  exerciseId: string,
  set: WorkoutSet
) {
  if (set.weight <= 0 || set.reps <= 0) {
    return false;
  }

  const currentScore =
    estimatedOneRepMax(
      set.weight,
      set.reps
    );

  let previousBest = 0;

  history.forEach((workout) => {
    workout.exercises.forEach(
      (exercise) => {
        if (
          exercise.exerciseId !== exerciseId
        ) {
          return;
        }

        exercise.sets.forEach(
          (previousSet) => {
            previousBest = Math.max(
              previousBest,
              estimatedOneRepMax(
                previousSet.weight,
                previousSet.reps
              )
            );
          }
        );
      }
    );
  });

  return currentScore > previousBest;
}

function formatDate(value: string) {
  return new Date(value).toLocaleString(
    undefined,
    {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }
  );
}

function formatTime(value: string) {
  return new Date(value).toLocaleTimeString(
    undefined,
    {
      hour: "2-digit",
      minute: "2-digit",
    }
  );
}

function formatLiveDuration(seconds: number) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor(
    (seconds % 3600) / 60
  );
  const remainingSeconds = seconds % 60;

  return [hours, minutes, remainingSeconds]
    .map((value) =>
      String(value).padStart(2, "0")
    )
    .join(":");
}

function formatDuration(seconds: number) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor(
    (seconds % 3600) / 60
  );

  if (hours > 0) {
    return `${hours}h ${minutes}min`;
  }

  return `${Math.max(minutes, 1)}min`;
}


function LiveMetric({label,value}:{label:string;value:string|number}) {
  return <div className="rounded-2xl bg-slate-50 p-3"><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{label}</p><p className="mt-1 font-mono text-sm font-black text-slate-900">{value}</p></div>;
}
function SummaryMetric({label,value}:{label:string;value:string|number}) {
  return <div className="rounded-2xl bg-slate-50 p-4 text-center"><p className="text-xs font-bold uppercase tracking-wider text-slate-400">{label}</p><p className="mt-2 text-lg font-black">{value}</p></div>;
}
function BuilderNumber({label,value,onChange}:{label:string;value:number;onChange:(v:number)=>void}) {
  return <label className="text-xs font-bold text-slate-500">{label}<input type="number" min="1" value={value} onChange={e=>onChange(Number(e.target.value)||1)} className="mt-1 w-full rounded-xl border border-slate-200 p-2 text-center text-sm font-black text-slate-900"/></label>;
}
function ExerciseProgressMini({history,exerciseId,displayUnits}:{history:WorkoutHistoryEntry[];exerciseId:string;displayUnits:"metric"|"imperial"}) {
  const performances=history.flatMap(w=>w.exercises.filter(e=>e.exerciseId===exerciseId).flatMap(e=>e.sets.map(set=>({weight:set.weight,reps:set.reps}))));
  const best=performances.reduce((m,p)=>p.weight>m.weight?p:m,{weight:0,reps:0});
  const last=performances[0];
  return <div className="rounded-2xl border border-slate-200 bg-white p-4"><p className="text-xs font-bold uppercase tracking-widest text-slate-400">Progress</p><div className="mt-3 grid grid-cols-2 gap-2"><div><p className="text-xs text-slate-400">Best</p><p className="font-black">{formatStoredWeight(best.weight||0, displayUnits)}</p></div><div><p className="text-xs text-slate-400">Last</p><p className="font-black">{last?`${formatStoredWeight(last.weight, displayUnits)} × ${last.reps}`:"—"}</p></div></div></div>;
}


function estimated1RM(weight: number, reps: number) {
  if (!weight || !reps) return 0;
  return weight * (1 + reps / 30);
}

function ExerciseDetailStats({ history, exerciseId, displayUnits }: { history: WorkoutHistoryEntry[]; exerciseId: string; displayUnits: "metric" | "imperial" }) {
  const sessions = history.flatMap((workout) =>
    workout.exercises
      .filter((exercise) => exercise.exerciseId === exerciseId)
      .map((exercise) => ({
        date: workout.finishedAt,
        volume: exercise.sets.reduce((sum, set) => sum + set.weight * set.reps, 0),
        best: exercise.sets.reduce((best, set) => estimated1RM(set.weight, set.reps) > estimated1RM(best.weight, best.reps) ? set : best, { id:"", weight:0, reps:0, rir:null, completed:false } as WorkoutSet)
      }))
  ).slice(0, 12);
  const bestWeight = sessions.reduce((m, row) => Math.max(m, row.best.weight), 0);
  const bestE1rm = sessions.reduce((m, row) => Math.max(m, estimated1RM(row.best.weight, row.best.reps)), 0);
  const maxVolume = sessions.reduce((m, row) => Math.max(m, row.volume), 0);
  const chartMax = Math.max(1, ...sessions.map((row) => estimated1RM(row.best.weight, row.best.reps)));

  return <div>
    <div className="grid grid-cols-3 gap-3">
      <SummaryMetric label="Best weight" value={formatStoredWeight(bestWeight, displayUnits)} />
      <SummaryMetric label="Est. 1RM" value={formatStoredWeight(bestE1rm, displayUnits)} />
      <SummaryMetric label="Best volume" value={formatStoredVolume(maxVolume, displayUnits)} />
    </div>
    <div className="mt-5 rounded-2xl border border-slate-200 p-4">
      <p className="text-sm font-black">Strength trend · e1RM</p>
      <div className="mt-5 flex h-40 items-end gap-2">
        {[...sessions].reverse().map((row, index) => {
          const value = estimated1RM(row.best.weight, row.best.reps);
          return <div key={`${row.date}-${index}`} className="flex flex-1 flex-col items-center justify-end gap-2">
            <span className="text-[9px] font-bold text-slate-400">{Math.round(value)}</span>
            <div className="w-full rounded-t-lg bg-emerald-400" style={{height:`${Math.max(6,(value/chartMax)*110)}px`}} />
          </div>;
        })}
      </div>
    </div>
    <div className="mt-5 space-y-2">
      {sessions.map((row, index) => <div key={`${row.date}-${index}`} className="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3 text-sm">
        <span className="text-slate-500">{new Date(row.date).toLocaleDateString()}</span>
        <span className="font-black">{formatStoredWeight(row.best.weight, displayUnits)} × {row.best.reps} · e1RM {formatStoredWeight(estimated1RM(row.best.weight,row.best.reps), displayUnits)}</span>
      </div>)}
      {!sessions.length && <p className="rounded-xl bg-slate-50 p-4 text-sm text-slate-400">No exercise history yet.</p>}
    </div>
  </div>;
}

function AnalyticsTab({ history, exercises, displayUnits }: { history: WorkoutHistoryEntry[]; exercises: Exercise[]; displayUnits: "metric" | "imperial" }) {
  const [range, setRange] = useState<7 | 30 | 90>(30);
  const cutoff = Date.now() - range * 86400000;
  const recent = history.filter((workout) => new Date(workout.finishedAt).getTime() >= cutoff);
  const totalSets = recent.reduce((total, workout) => total + workout.exercises.reduce((sum, exercise) => sum + exercise.sets.length, 0), 0);
  const totalVolume = recent.reduce((total, workout) => total + workout.exercises.reduce((sum, exercise) => sum + exercise.sets.reduce((v, set) => v + set.weight * set.reps, 0), 0), 0);
  const avgDuration = recent.length ? recent.reduce((sum, workout) => sum + workout.durationSeconds, 0) / recent.length : 0;

  const muscleSets: Record<string, number> = {};
  recent.forEach((workout) => workout.exercises.forEach((exercise) => {
    const muscle = exercises.find((e) => e.id === exercise.exerciseId)?.muscleGroup || "Other";
    muscleSets[muscle] = (muscleSets[muscle] || 0) + exercise.sets.length;
  }));
  const maxMuscle = Math.max(1, ...Object.values(muscleSets));

  const prs = history.flatMap((workout) => workout.exercises.flatMap((exercise) =>
    exercise.sets.map((set) => ({ date: workout.finishedAt, name: exercise.exerciseName, weight: set.weight, reps: set.reps, e1rm: estimated1RM(set.weight,set.reps) }))
  )).sort((a,b)=>b.e1rm-a.e1rm).slice(0,8);

  return <section className="mt-8">
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div><p className="text-xs font-bold uppercase tracking-widest text-emerald-600">Training Analytics</p><h2 className="mt-1 text-3xl font-black">Your training at a glance</h2><p className="mt-2 text-slate-500">Volume, frequency, muscle balance and strength trends.</p></div>
      <div className="flex rounded-xl bg-slate-100 p-1">{([7,30,90] as const).map((days)=><button key={days} onClick={()=>setRange(days)} className={`rounded-lg px-4 py-2 text-xs font-black ${range===days?"bg-white text-slate-950 shadow-sm":"text-slate-500"}`}>{days}D</button>)}</div>
    </div>
    <div className="mt-6 grid gap-3 sm:grid-cols-4">
      <SummaryMetric label="Workouts" value={recent.length}/>
      <SummaryMetric label="Working sets" value={totalSets}/>
      <SummaryMetric label="Volume" value={formatStoredVolume(totalVolume, displayUnits)}/>
      <SummaryMetric label="Avg duration" value={formatDuration(Math.round(avgDuration))}/>
    </div>
    <div className="mt-6 grid gap-6 lg:grid-cols-2">
      <div className="rounded-3xl border border-slate-200 bg-white p-6">
        <h3 className="text-xl font-black">Sets by muscle</h3>
        <div className="mt-5 space-y-4">{Object.entries(muscleSets).sort((a,b)=>b[1]-a[1]).map(([muscle,sets])=><div key={muscle}><div className="flex justify-between text-sm"><span className="font-bold">{muscle}</span><span className="text-slate-400">{sets} sets</span></div><div className="mt-2 h-2 rounded-full bg-slate-100"><div className="h-2 rounded-full bg-emerald-400" style={{width:`${(sets/maxMuscle)*100}%`}}/></div></div>)}{!Object.keys(muscleSets).length&&<p className="text-sm text-slate-400">Finish workouts to unlock muscle analytics.</p>}</div>
      </div>
      <div className="rounded-3xl border border-slate-200 bg-white p-6">
        <h3 className="text-xl font-black">Top performances</h3>
        <div className="mt-5 space-y-2">{prs.map((pr,index)=><div key={`${pr.date}-${pr.name}-${index}`} className="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3"><div><p className="text-sm font-bold">{pr.name}</p><p className="text-xs text-slate-400">{new Date(pr.date).toLocaleDateString()}</p></div><div className="text-right"><p className="text-sm font-black">{formatStoredWeight(pr.weight, displayUnits)} × {pr.reps}</p><p className="text-xs font-bold text-emerald-600">e1RM {formatStoredWeight(pr.e1rm, displayUnits)}</p></div></div>)}</div>
      </div>
    </div>
  </section>;
}

function WorkoutV2Chip({title,detail}:{title:string;detail:string}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <p className="text-sm font-black text-slate-900">{title}</p>
      <p className="mt-1 text-xs text-slate-500">{detail}</p>
    </div>
  );
}

function WorkoutHeroStat({
  label,
  value,
}: {
  label: string;
  value: string | number;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-3">
      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
        {label}
      </p>
      <p className="mt-1 text-lg font-black text-slate-900">{value}</p>
    </div>
  );
}

function makeId() {
  return `${Date.now()}-${Math.random()
    .toString(36)
    .slice(2, 9)}`;
}